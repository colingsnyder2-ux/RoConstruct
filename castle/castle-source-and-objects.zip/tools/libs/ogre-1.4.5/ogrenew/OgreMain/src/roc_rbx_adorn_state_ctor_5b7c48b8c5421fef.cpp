#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>

// Re-emitted for server verification after a stale local C1088 temp-file failure.

namespace Ogre {

class RbxAdornState {
public:
    void* renderable;
    bool enabled;
    void* material;
    int operationType;
    ColourValue colour;
    Vector3 offset;

    RbxAdornState();
};

RbxAdornState::RbxAdornState()
{
    renderable = 0;
    enabled = false;
    material = 0;
    operationType = 2;
    colour = ColourValue(-1.0f, -1.0f, -1.0f, -1.0f);
    offset = Vector3(0.0f, 0.0f, 0.0f);
}

}
