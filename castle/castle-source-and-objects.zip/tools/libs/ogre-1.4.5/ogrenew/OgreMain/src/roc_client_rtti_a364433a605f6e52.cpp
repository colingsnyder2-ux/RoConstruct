#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
template class Ogre::SharedPtr<Ogre::GpuProgramParameters>;
