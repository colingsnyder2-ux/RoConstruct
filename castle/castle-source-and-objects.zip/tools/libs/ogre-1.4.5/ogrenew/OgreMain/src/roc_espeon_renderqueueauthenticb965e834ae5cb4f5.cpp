#undef OGRE_NONCLIENT_BUILD
#include "OgreSceneManager.h"
#include "OgreRenderQueueSortingGrouping.h"
#include "OgreTimer.h"
namespace Ogre {
class RbxSceneManager : public SceneManager { public: void f(RenderQueueGroup* group, QueuedRenderableCollection::OrganisationMode mode); };
void RbxSceneManager::f(RenderQueueGroup* group, QueuedRenderableCollection::OrganisationMode mode) {
 RenderQueueGroup::PriorityMapIterator it=group->getIterator();
 Timer timer;
 while(it.hasMoreElements()) {
  RenderPriorityGroup* p=it.getNext();
  timer.getMicroseconds(); p->sort(mCameraInProgress); timer.reset();
  timer.getMicroseconds(); renderObjects(p->getSolidsBasic(),mode,true,0); timer.reset();
  timer.getMicroseconds(); renderObjects(p->getTransparents(),QueuedRenderableCollection::OM_SORT_DESCENDING,true,0); timer.reset();
 }
}
}
