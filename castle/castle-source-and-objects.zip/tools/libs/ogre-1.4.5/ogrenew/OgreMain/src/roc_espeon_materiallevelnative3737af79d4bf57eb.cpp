#undef OGRE_NONCLIENT_BUILD
#include "OgreMaterialManager.h"
#include "OgreMaterial.h"
#include "OgreLogManager.h"
extern "C" __declspec(dllimport) long __stdcall InterlockedDecrement(volatile long*);
struct Control {
    virtual ~Control();
    volatile long count;
    void *object;
    void release();
};

struct Reference {
    Control *p;
    ~Reference();
};

inline Reference::~Reference()
{
    if (p) {
        if (InterlockedDecrement(&p->count) == 0) {
            p->release();
            if (p)
                delete p;
        }
        p = 0;
    }
}

struct Base {
    virtual ~Base();
};

inline Base::~Base()
{
}

struct Level : Base {
    unsigned long reserved0;
    Reference first;
    Reference second;
    unsigned char reserved1[28];
    Ogre::MaterialPtr material;
    ~Level();
};

Level::~Level(){
 if(!material.isNull()){
 Ogre::String name(material->getName());
 Ogre::MaterialManager::getSingleton().remove(material->getHandle());
 Ogre::LogManager::getSingleton().logMessage("RBX removed "+name,Ogre::LML_NORMAL,false);
 }
}
