#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
#include <vector>
#include <algorithm>
struct Entry {
    void* object;
    float priority;
    bool operator<(const Entry& other) const { return priority < other.priority; }
};
void heapPush(std::vector<Entry>& values) { std::push_heap(values.begin(), values.end()); }
void heapPop(std::vector<Entry>& values) { std::pop_heap(values.begin(), values.end()); }
void heapSort(Entry* first, Entry* last) { std::sort_heap(first, last); }
void heapMake(Entry* first, Entry* last) { std::make_heap(first, last); }
