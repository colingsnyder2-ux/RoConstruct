#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
#include <OgreEdgeListBuilder.h>
namespace Ogre {
class RbxSubMesh : public SubMesh {
public:
    bool prepared;
    EdgeData* edges;
    AxisAlignedBox bounds;
    ~RbxSubMesh();
    void prepareEdges();
};
RbxSubMesh::~RbxSubMesh() { delete edges; }
void RbxSubMesh::prepareEdges() {
    if (prepared) return;
    vertexData->prepareForShadowVolume();
    prepared = true;
    EdgeListBuilder builder;
    builder.addVertexData(vertexData);
    builder.addIndexData(indexData, 0, operationType);
    edges = builder.build();
}
}
