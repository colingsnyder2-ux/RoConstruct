#undef OGRE_NONCLIENT_BUILD
#include <OgreSubEntity.h>
#include <OgreMatrix4.h>
namespace Ogre { class RbxSubEntity : public SubEntity { public: __declspec(align(16)) Matrix4 transform; void getWorldTransforms(Matrix4* out) const; };
void RbxSubEntity::getWorldTransforms(Matrix4* out) const { *out = transform; } }
