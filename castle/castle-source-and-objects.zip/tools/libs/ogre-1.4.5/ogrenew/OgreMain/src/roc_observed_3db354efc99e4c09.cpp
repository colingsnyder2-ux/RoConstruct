#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>

namespace Ogre {
// Codegen analog on the genuine vendor layout. The two stack arguments are
// proven by ret 8; the target ignores them and copies the local transform.
class RbxSceneNode : public SceneNode {
public:
    void _update(bool, bool);
};
void RbxSceneNode::_update(bool, bool) {
    mDerivedOrientation.w = mOrientation.w;
    mDerivedOrientation.x = mOrientation.x;
    mDerivedOrientation.y = mOrientation.y;
    mDerivedOrientation.z = mOrientation.z;
    mDerivedPosition.x = mPosition.x;
    mDerivedPosition.y = mPosition.y;
    mDerivedPosition.z = mPosition.z;
    mDerivedScale.x = mScale.x;
    mDerivedScale.y = mScale.y;
    mDerivedScale.z = mScale.z;
    mWorldAABB.setExtents(-10000.0f, -10000.0f, -10000.0f,
                        10000.0f, 10000.0f, 10000.0f);
}
}
