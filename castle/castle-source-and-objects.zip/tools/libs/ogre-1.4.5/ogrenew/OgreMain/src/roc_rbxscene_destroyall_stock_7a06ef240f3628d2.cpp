#include "roc_rbxscene_ctor_0606b79b7c96ed1a.cpp"

namespace Ogre {

void RbxSceneManager::destroyAllCameras(void)
{
    CameraList::iterator i = mCameras.begin();
    for (; i != mCameras.end(); ++i)
    {
        mDestRenderSystem->_notifyCameraRemoved(i->second);
        delete i->second;
    }
    mCameras.clear();
}

}
