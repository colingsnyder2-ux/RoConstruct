#include <Ogre.h>
template class Ogre::SharedPtr<Ogre::GpuProgramParameters>;
