#undef OGRE_NONCLIENT_BUILD
#include <OgreSceneManager.h>
#include <OgreSceneNode.h>
struct HeaderRecovery : Ogre::SceneManager { void recoverUpdate(Ogre::Camera* cam); };
void HeaderRecovery::recoverUpdate(Ogre::Camera* cam) {
 Ogre::Node::processQueuedUpdates();
 mSceneRoot->_update(true, false);
}
