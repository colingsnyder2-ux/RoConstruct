#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
#include <set>
namespace Ogre {
class RbxSceneNode : public SceneNode {
public:
    RbxSceneNode();
    std::set<unsigned int> mSet;
    bool has(unsigned int key);
};
bool RbxSceneNode::has(unsigned int key)
{
    std::set<unsigned int>::iterator it = mSet.find(key);
    return it != mSet.end();
}
}
