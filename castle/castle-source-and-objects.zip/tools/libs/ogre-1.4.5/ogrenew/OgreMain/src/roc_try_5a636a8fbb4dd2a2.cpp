#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
namespace Ogre {
class RbxSceneManager : public SceneManager {
public:
    Entity* createEntity(const String& entityName, PrefabType ptype);
    Entity* createEntity(const String& entityName, const String& meshName);
};
#line 421 ".\\RbxSceneManager.cpp"
Entity* RbxSceneManager::createEntity(const String& entityName, PrefabType ptype)
{
    switch (ptype)
    {
    case PT_PLANE:
        return createEntity(entityName, "Prefab_Plane");
	case PT_CUBE:
		return createEntity(entityName, "Prefab_Cube");
	case PT_SPHERE:
		return createEntity(entityName, "Prefab_Sphere");

        break;
    }

    OGRE_EXCEPT( Exception::ERR_ITEM_NOT_FOUND, 
        "Unknown prefab type for entity " + entityName,
        "RbxSceneManager::createEntity");
}
}
