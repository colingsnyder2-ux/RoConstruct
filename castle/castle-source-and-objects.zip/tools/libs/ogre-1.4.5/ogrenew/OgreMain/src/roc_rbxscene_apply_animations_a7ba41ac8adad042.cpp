#define RbxSceneManager RbxSceneManagerBase
#include "roc_fork_ea71c50b47f88007.cpp"
#undef RbxSceneManager

namespace Ogre {

class RbxSceneManager : public RbxSceneManagerBase {
public:
    virtual void _applySceneAnimations(void);
};

void RbxSceneManager::_applySceneAnimations(void)
{
    OGRE_LOCK_MUTEX(mAnimationStates.OGRE_AUTO_MUTEX_NAME)

    ConstEnabledAnimationStateIterator stateIt =
        mAnimationStates.getEnabledAnimationStateIterator();

    while (stateIt.hasMoreElements())
    {
        const AnimationState* state = stateIt.getNext();
        Animation* animation = getAnimation(state->getAnimationName());

        Animation::NodeTrackIterator nodeTrackIt = animation->getNodeTrackIterator();
        while (nodeTrackIt.hasMoreElements())
        {
            Node* node = nodeTrackIt.getNext()->getAssociatedNode();
            node->resetToInitialState();
        }

        Animation::NumericTrackIterator numericTrackIt =
            animation->getNumericTrackIterator();
        while (numericTrackIt.hasMoreElements())
        {
            const AnimableValuePtr& value =
                numericTrackIt.getNext()->getAssociatedAnimable();
            value->resetToBaseValue();
        }

        animation->apply(state->getTimePosition(), state->getWeight());
    }
}

}
