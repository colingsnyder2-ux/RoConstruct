#undef OGRE_NONCLIENT_BUILD
#include <OgreSceneManager.h>
using namespace Ogre;
class SceneMgrQueuedRenderableVisitor : public QueuedRenderableVisitor
		{
		protected:
			/// Pass that was actually used at the grouping level
			const Pass* mUsedPass;
		public:
			SceneMgrQueuedRenderableVisitor() 
				:transparentShadowCastersMode(false) {}
			~SceneMgrQueuedRenderableVisitor();
			void visit(const Renderable* r);
			bool visit(const Pass* p);
			void visit(const RenderablePass* rp);

			/// Target SM to send renderables to
			SceneManager* targetSceneMgr;
			/// Are we in transparent shadow caster mode?
			bool transparentShadowCastersMode;
			/// Automatic light handling?
			bool autoLights;
			/// Manual light list
			const LightList* manualLightList;

		};
SceneMgrQueuedRenderableVisitor::~SceneMgrQueuedRenderableVisitor() {}
