#undef OGRE_NONCLIENT_BUILD
#include "OgreSubEntity.h"
#include "OgreEntity.h"
#include "OgreSceneNode.h"
#include "OgreCamera.h"
#include "OgreMatrix4.h"
namespace Ogre {
class RbxSceneNode:public SceneNode {};
class RbxSubEntity:public SubEntity {
 unsigned fieldEC;
 Matrix4 transform;
 public: Real getSquaredViewDepth(const Camera* cam) const;
};
Real RbxSubEntity::getSquaredViewDepth(const Camera* cam) const {
 if(mCachedCamera==cam)return mCachedCameraDist;
 RbxSceneNode* node=dynamic_cast<RbxSceneNode*>(mParentEntity->getParentNode());
 Vector3 position=transform.getTrans();
 return (position-cam->getDerivedPosition()).squaredLength();
}
}
