#undef OGRE_NONCLIENT_BUILD
#include <OgreSceneManager.h>
#include <algorithm>
struct HeaderAccess : Ogre::SceneManager {
 using Ogre::SceneManager::lightsForShadowTextureLess;
 using Ogre::SceneManager::LightInfo;
};
template void std::_Buffered_merge(Ogre::Light**, Ogre::Light**, Ogre::Light**, int, int, std::_Temp_iterator<Ogre::Light*>&, HeaderAccess::lightsForShadowTextureLess);
template class std::vector<HeaderAccess::LightInfo>;
