#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
#include <list>
struct Quad { float values[12]; };
void addQuad(std::list<Quad>& quads, const Quad& quad) { quads.push_back(quad); quads.push_front(quad); quads.insert(++quads.begin(), quad); }
