#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
#include <map>

template class std::map<Ogre::String, Ogre::MeshPtr>;

