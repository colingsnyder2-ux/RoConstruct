#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
namespace Ogre {
class VisualEngine {
    char reserved[0xcc];
    MeshPtr mMesh;
public:
    void setMesh(MeshPtr mesh);
};
void VisualEngine::setMesh(MeshPtr mesh) { mMesh = mesh; }
}
