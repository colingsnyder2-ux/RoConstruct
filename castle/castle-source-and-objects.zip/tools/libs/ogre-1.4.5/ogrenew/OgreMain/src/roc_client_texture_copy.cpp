#undef OGRE_NONCLIENT_BUILD
#include <OgreTexture.h>
#include <algorithm>
template Ogre::TexturePtr* std::_Copy_opt(Ogre::TexturePtr*, Ogre::TexturePtr*, Ogre::TexturePtr*, std::random_access_iterator_tag, std::_Nonscalar_ptr_iterator_tag, std::_Range_checked_iterator_tag);
