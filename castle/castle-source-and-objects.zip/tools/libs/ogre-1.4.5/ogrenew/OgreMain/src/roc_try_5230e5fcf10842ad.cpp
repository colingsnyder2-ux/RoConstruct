#undef OGRE_NONCLIENT_BUILD
#include <Ogre.h>
using namespace Ogre;
#include <map>
typedef std::map<const Light*, Vector4> LightPositionMap;
void cacheLightPosition(LightPositionMap& positions, const Light* light, const Vector4& position)
{
    positions[light] = position;
}
