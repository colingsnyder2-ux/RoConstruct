$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$files = Get-ChildItem -File "RenderScene_31pct_*.cpp" | Sort-Object Name
$logDir = Join-Path $PSScriptRoot "RenderScene_31pct_logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$rows = @()
foreach ($f in $files) {
    Write-Host "`n--- $($f.Name) ---"
    $result = & .\roc.cmd check 2008-06 007ab0a0 --file ".\$($f.Name)" --context 3 2>&1 | Out-String
    $log = Join-Path $logDir ($f.BaseName + ".log")
    $result | Set-Content -Path $log
    $score = "FAILED"
    if ($result -match '007ab0a0\s+(\d+)%') { $score = $Matches[1] + "%" }
    Write-Host "$score - $($f.Name)"
    if ($score -eq "FAILED") { Write-Host (($result -split "`n" | Select-Object -First 8) -join "`n") }
    $rows += [PSCustomObject]@{Candidate=$f.Name; Score=$score; Log=$log}
}
$rows | Format-Table -AutoSize
$rows | Export-Csv -Path (Join-Path $logDir "summary.csv") -NoTypeInformation
Write-Host "`nBest verified baseline: 31%. Do not overwrite src\2008-06\007ab0a0.cpp unless a trial improves it."
