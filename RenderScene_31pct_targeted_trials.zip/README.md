# RenderScene 31% targeted experiments

Starting evidence (user verified): **31%** selective rendering-helper inlining, **16%** forcing every helper.

All candidate files start from `RenderScene_24pct_inline_render.cpp` (31% baseline). Each changes only one isolated inlining group or matrix array length. No inline assembly or embedded bytes.

## Run

1. Extract every file in this zip into your RoConstruct repository root (same directory as `roc.cmd`).
2. Run `powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_31pct_test.ps1`.
3. Read the score table and logs under `RenderScene_31pct_logs`.
4. Preserve `src\2008-06\007ab0a0.cpp` until you have an improvement over 31%.

## Trials

| Name | Isolated change |
|---|---|
| no_sky | Allow normal inlining of GetSkyTexture, ConfigureSky |
| no_material | Allow normal inlining of ConfigurePass, BuildItemMaterial |
| no_bounds | Allow normal inlining of UpdateItemBounds, MergeItemBounds |
| no_geometry | Allow normal inlining of AddPerVertexOffsets, UpdateEntityTransform |
| force_queries | Force-inline QueryItem |
| force_refs | Force-inline ReleaseRef, ReleaseResource |
| force_lookup | Force-inline GetMaterialData, SelectMaterialEntry |
| force_distance | Force-inline DetermineItemDistanceFlag |
| force_geometry_access | Force-inline WorldPosition, FindSubMesh |
| matrix_64 | Use 0x40 matrix buffer rather than 0x80 |

The 0x40 matrix hypothesis is based on the 0x260 matrix stack area in the disassembly and a conventional Ogre::Matrix4 size of 64 bytes. It may be wrong; compiler score decides. Compilation/syntax is **not** a verified byte match.

If no variant beats 31%, obtain the first ~80 instructions of the **31% candidate's actual assembly diff** and generated function size before changing other fields or compiler flags. Prologue/stack matching depends on real temporary lifetimes, not arbitrary padding.
