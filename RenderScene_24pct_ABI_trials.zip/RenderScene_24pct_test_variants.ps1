$files = @(
    "RenderScene_24pct_virtual_thiscall.cpp",
    "RenderScene_24pct_internal_thiscall.cpp",
    "RenderScene_24pct_combined_thiscall.cpp"
)

foreach ($file in $files) {
    Write-Host "`n=== $file ==="
    if (-not (Test-Path $file)) {
        Write-Host "File missing: $file"
        continue
    }
    $log = & .\roc.cmd check 2008-06 007ab0a0 --file ".\$file" --context 2 2>&1
    $log | Select-Object -First 8
}
