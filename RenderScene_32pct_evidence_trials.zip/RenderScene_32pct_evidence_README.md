# RenderScene 32% — Evidence-based follow-up

All sources are **scratch experiments** based on the user-verified 32% `force_geometry_access` version. They are untested against the original binary until run locally. No source was promoted.

## Trials

- `interlocked_import`: At target 0x007AB503, 0x007AB67A and many other sites, the code calls `KERNEL32!InterlockedDecrement` indirectly via an import-table entry. Replace a custom `extern` function with `__declspec(dllimport) InterlockedDecrement`. May conflict with an imported declaration from existing Windows headers; treat errors as errors, not score zero.
- `exception_std`: The original exception path at 0x007ACBA7 constructs `std::exception` (annotated MSVCR90 imported symbol). Our candidate throws `std::runtime_error`. This is the smallest direct source correction to that path. Old MSVC 2008 supplies its own `std::exception` constructors.
- `pose_thiscall`: Target starts with ECX=pose and a single `push` for the destination at 0x007AB0E4. Change only `sub_5107B0` into an x86 C++ member call, not every internal helper at once.
- `scene_update_thiscall`: Target uses ECX=`this` and two pushes before call 0x007A9D30. Change only this method signature.
- `dont_macro_thiscall`: Stop defining `__thiscall` itself to empty before including real Ogre headers; make a separate `RS_THISCALL` macro instead. Member methods are still naturally `__thiscall` on x86 MSVC.
- `exception_plus_import`: Interaction test between the two strongly grounded changes. Only worth considering after individual scores.

## Run one at a time (avoids 120-second wrapper timeout)

Extract ZIP into the RoConstruct root and run:

```powershell
cd C:\Users\colin\RoConstruct
powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_32pct_evidence_test.ps1 -Name interlocked_import
powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_32pct_evidence_test.ps1 -Name exception_std
```

Change `-Name` to any name above to test it. The script uses `roc check --file`, keeps `src\2008-06\007ab0a0.cpp` unchanged, and writes full output to `RenderScene_32pct_evidence_logs`.

The score only measures byte similarity. Correct semantics, successful compilation, and 100% exact matching are separate milestones. Do not claim these variants are improvements before local `roc check`.
