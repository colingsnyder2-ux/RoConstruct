param(
    [ValidateSet('baseline','interlocked_import','exception_std','pose_thiscall','scene_update_thiscall','dont_macro_thiscall','exception_plus_import')]
    [string]$Name = 'interlocked_import'
)
$ErrorActionPreference = 'Continue'
Set-Location $PSScriptRoot
$folder = Join-Path $PSScriptRoot 'RenderScene_32pct_evidence'
$file = Join-Path $folder ("RenderScene_32pct_" + $Name + '.cpp')
$logfolder = Join-Path $PSScriptRoot 'RenderScene_32pct_evidence_logs'
New-Item -ItemType Directory -Path $logfolder -Force | Out-Null
if (!(Test-Path $file)) { throw "Candidate not found: $file" }
Write-Host "Checking $Name (live source not modified)"
$result = (& .\roc.cmd check 2008-06 007ab0a0 --file $file --context 3 2>&1 | Out-String)
$log = Join-Path $logfolder ("RenderScene_32pct_" + $Name + '.log')
$result | Set-Content $log
if ($result -match '007ab0a0\s+(\d+)%') {
    Write-Host "$Name`: $($Matches[1])% (best baseline: 32%)"
} else {
    Write-Host "No score (compile failure or missing tool):"
    Write-Host (($result -split "`r?`n" | Select-Object -First 15) -join "`n")
}
Write-Host "Full output: $log"
