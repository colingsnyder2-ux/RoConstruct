# RenderScene 35% target-specific trials

Baseline is the user-verified 35% `exception_std` variant from the last experiment. The original 35% source is copied unchanged; only the user can confirm the new scores with `roc check`.

## Why each change

- `exception_local_cstr`: at target 0x7ACB93 the original stores the exception text address in a local pointer and passes its address to `std::exception(const char* const&)`. Force a named pointer temporary instead of constructing directly from the literal.
- `exception_const_cstr`: same with a const pointer temporary, to check compiler codegen for reference binding.
- `pose_thiscall`: at target 0x7AB0E4 ECX holds `pose`, with the output matrix pointer on the stack. Change **only** that internal call to MSVC member-style thiscall.
- `scene_update_thiscall`: at target 0x7AB2DE ECX holds `this`, with two parameters pushed. Isolate that call.
- `distance_thiscall`: at target 0x7AB880 ECX holds the owning object and two parameters are on the stack. Fix both calls to `sub_548F80` together.
- `target_ctor_thiscall`: at target 0x7AB48F ECX holds allocated memory and no other arguments are passed. Isolate the constructor call.

Note: C++ aliases for the unknown direct-call functions are intentionally just unimplemented method declarations. Linking is not the aim of `roc check`. No inline assembly or byte blobs.

## Running one variant at a time

Extract this ZIP into the repository root (not into src/). Test one variant per command to avoid wrapper timeouts.

```powershell
cd C:\Users\colin\RoConstruct
powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_35pct_test.ps1 -Name exception_local_cstr
powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_35pct_test.ps1 -Name distance_thiscall
```

The script saves diffs under `RenderScene_35pct_logs` without changing `src/2008-06/007ab0a0.cpp`. Other variants use their names above. If no variant scores higher than 35%, the important next input is the first full target vs generated prologue diff, not more arbitrary stack padding.
