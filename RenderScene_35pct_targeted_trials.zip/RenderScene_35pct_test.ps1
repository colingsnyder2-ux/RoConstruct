param(
    [ValidateSet('baseline','exception_local_cstr','exception_const_cstr','pose_thiscall','scene_update_thiscall','distance_thiscall','target_ctor_thiscall')]
    [string]$Name='exception_local_cstr'
)
Set-Location $PSScriptRoot
$src = Join-Path $PSScriptRoot ("RenderScene_35pct_trials\RenderScene_35pct_" + $Name + '.cpp')
$logDir = Join-Path $PSScriptRoot 'RenderScene_35pct_logs'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
if (!(Test-Path $src)) { throw "Missing test source: $src" }
Write-Host "=== $Name ===" 
$log = Join-Path $logDir ($Name + '.log')
$result = & .\roc.cmd check 2008-06 007ab0a0 --file $src --context 3 2>&1 | Out-String
$result | Set-Content -Path $log
if ($result -match '007ab0a0\s+(\d+)%') {
    Write-Host ("{0}: {1}% (best known baseline 35%)" -f $Name,$Matches[1])
} else {
    Write-Host 'No score returned. First lines of compiler/error output:'
    $result -split "`r?`n" | Select-Object -First 20 | ForEach-Object { Write-Host $_ }
}
Write-Host "Full output: $log"
