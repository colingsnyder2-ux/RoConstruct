// 2008-06 native RBX::SimBody rows (inactive) against native-headers/v8kernel/Body2008.h (the 0xb4 SimBody):
// SimBody(Body*) 00658ae0, getOwnerPV 00658ca0 (SimBody unit 00658a30..0065925e) and accumulateForce 00612fb0 (its
// out-of-line copy precedes the GeoPair unit 00613060). Verified by tests/record_native_body_primitive2008.py.
// native-flags: /O2 /Ob2 /Oy /GF /GS- /EHsc /MD /D_AFXDLL /DNDEBUG /D_MBCS /fp:fast
#include "v8kernel/Body2008.h"
#include "v8kernel/Constants.h"
#include "util/Units.h"

namespace RBX
{
	static inline G3D::Vector3 reciprocal(const G3D::Vector3& v)
	{
		return G3D::Vector3(1.0f / v.x, 1.0f / v.y, 1.0f / v.z);
	}

	// 00658ae0: dt +0x4 = 0, dirty +0x8, PV() +0xc, Quaternion() +0x54 = (0, 0, 0, 1), angMomentum / momentRecip zeroed by
	// Vector3(), constantForceY +0x80 = 0, then the four accumulators from the Vector3::zero() static (0096f044).
	SimBody::SimBody(Body* _body)
		: body(_body),
		  dt(0.0f),
		  dirty(true),
		  constantForceY(0.0f),
		  force(G3D::Vector3::zero()),
		  torque(G3D::Vector3::zero()),
		  impulse(G3D::Vector3::zero()),
		  rotImpulse(G3D::Vector3::zero())
	{
	}

	// 00658d20
	// Parked (hard-leftover lf14): same size (643 bytes), calls and stores match; two x87 scheduling differences remain.
	// 1) the unit-quaternion scale: the original loads the reciprocal first for x and y (fld st(0); fmul [q.x]) where
	//    this build loads the component (fld [q.x]; fmul st(1)); z and w already agree. 2) angMomentum = rotational *
	//    IWorld (Vector3 * Matrix3 inline): the original sums x*m00 + z*m20 + y*m10 per column, this build z, y, x.
	// Rejected: qOrientation = qOrientation * s (Quaternion::operator* plus out-of-line operator=, 660 bytes);
	// component-wise q.x *= s ... (same component-first pattern). Both depend on the donor util/Quaternion.h and G3D
	// Matrix3.h inline bodies, not on this body (header question).
	void SimBody::update()
	{
		{
			const G3D::Vector3 cofmOffset = body->getCofmOffset();
			pv = body->getPV().pvAtLocalOffset(cofmOffset);
		}
		qOrientation = Quaternion(pv.position.rotation);
		qOrientation *= 1.0f / qOrientation.magnitude();
		angMomentum = pv.velocity.rotational * body->getBranchIWorld();
		massRecip = 1.0f / body->getBranchMass();
		momentRecip = reciprocal(Math::toDiagonal(body->getBranchIBody()));
		constantForceY = body->getBranchMass() * Units::kmsAccelerationToRbx(Constants::getKmsGravity()).y;
		dirty = false;
	}

	// 00658ca0
	PV SimBody::getOwnerPV()
	{
		G3D::Vector3 cofmOffset = body->getCofmOffset();
		return pv.pvAtLocalOffset(G3D::Vector3(-cofmOffset.x, -cofmOffset.y, -cofmOffset.z));
	}

	// 00612fb0
	void SimBody::accumulateForce(const G3D::Vector3& _force, const G3D::Vector3& worldPos)
	{
		updateIfDirty();
		force += _force;
		torque += (worldPos - pv.position.translation).cross(_force);
	}
}
