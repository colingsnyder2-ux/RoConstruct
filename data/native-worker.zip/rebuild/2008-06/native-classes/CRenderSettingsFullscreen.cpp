// >>> native-status (generated) -- do not edit >>>
// CRenderSettingsFullscreen | 2008-06 | draft (no current byte proof)
// no original address mapped to this file yet | by -
// <<< native-status | src a05cf324 | roc native-status --write
#include "CRenderSettings.h"

G3D::Vector2int16 CRenderSettings::getFullscreenSize() const
{
    return fullscreenSize;
}

