// >>> native-status (generated) -- do not edit >>>
// DecalLifetime | 2008-06 | draft (no current byte proof)
// no original address mapped to this file yet | by -
// <<< native-status | src 967d3293 | roc native-status --write
#include "v8datamodel/Decal.h"

namespace RBX {
Decal::Decal() : specular(0.0f), shiny(20.0f) { setName("Decal"); }
Texture::Texture() : studsPerTile(2.0f, 2.0f) { setName("Texture"); }
}
