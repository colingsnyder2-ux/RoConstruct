// 2008-06 native RBX::ClickDetector (inactive); evidence in native-headers/v8datamodel/ClickDetector.h.
// Verified by tests/record_native_click_detector.py. Original unit 00629340..00629b9a, initializers
// 007f7d20..007f7d90, atexit 00800330..00800370; classDescriptor 005c02b0, doDeclare 005bf800.
// ServiceProvider::findServiceProvider (004898d0), Instance::findFirstChildOfType<T> (006294a0), RBX::Workspace and
// RBX::ModelInstance come from the committed native headers.
// native-flags: /O2 /Ob2 /Oy /GF /GS- /EHsc /MD /D_AFXDLL /DNDEBUG /D_MBCS /fp:fast
// >>> native-status (generated) -- do not edit >>>
// ClickDetector | 2008-06 | 1 byte-exact, inactive (not link-selected)
// 1/2 mapped addresses byte-exact | 1 unproved | no mapped strings | by king_originala (mixed 2)
// <<< native-status | src bb49f159 | roc native-status --write
#include "v8datamodel/ClickDetector.h"
#include "v8datamodel/PartInstance.h"
#include "Network/Players.h"
#include "v8datamodel/ModelInstance.h"
#include "v8datamodel/Workspace.h"

namespace RBX
{
	char sClickDetector[] = "ClickDetector"; // 0095b3c8 (doDeclare 005bf800, classDescriptor 005c02b0)

	// Template members the shared headers only declare (same definitions as Team.cpp / Sparkles.cpp).
	template<class C, class D, const char* N>
	FactoryProduct<C, D, N>::FactoryProduct() : D() {}

	template<class C, class D, const char* N>
	const Name& FactoryProduct<C, D, N>::className() { return Name::declare<N>(); }

	template<class C, class D, const char* N>
	const Name& FactoryProduct<C, D, N>::getClassName() const { return className(); }

	template<class C, class D, const char* N>
	DescribedCreatable<C, D, N>::DescribedCreatable()
		: Reflection::Described<C, N, FactoryProduct<C, D, N> >() {}

	// Dynamic initializers 007f7d20, 007f7d50, 007f7d90 (in this order).
	Reflection::SignalDesc<ClickDetector, void(void)> ClickDetector::event_MouseClick("MouseClick");
	static Reflection::PropDescriptor<ClickDetector, bool> desc_FrontendMouseClick("FrontendMouseClick", "Behavior", &ClickDetector::getFrontendMouseClick, &ClickDetector::setFrontendMouseClick, Reflection::PropertyDescriptor::STREAMING);
	Reflection::BoundProp<float, 1> ClickDetector::prop_MaxActivationDistance("MaxActivationDistance", "Data", &ClickDetector::maxActivationDistance, Reflection::PropertyDescriptor::STANDARD);

	ClickDetector::ClickDetector()
		: zeroInitialized(0),
		  maxActivationDistance(32.0f)
	{
		setName("ClickDetector");
	}

	ClickDetector::~ClickDetector()
	{
	}

	bool ClickDetector::askSetParent(const Instance* instance) const
	{
		return dynamic_cast<const PartInstance*>(instance) != 0 || dynamic_cast<const ModelInstance*>(instance) != 0;
	}

	void ClickDetector::setFrontendMouseClick(bool value)
	{
		if (ServiceProvider::findServiceProvider(this) && Network::Players::backendProcessing(this, true))
			event_MouseClick.fire(this);
	}

	void ClickDetector::click(PartInstance* part, float distance)
	{
		if (distance < maxActivationDistance)
		{
			frontendMouseClick = !frontendMouseClick;
			raisePropertyChanged(desc_FrontendMouseClick);
			if (Network::Players::backendProcessing(this, true))
				event_MouseClick.fire(this);
		}
	}

	bool ClickDetector::isClickable(PartInstance* part, float distance, bool raiseClickedEvent)
	{
		if (part)
		{
			Instance* instance = part;
			do
			{
				ClickDetector* detector = instance->findFirstChildOfType<ClickDetector>();
				if (detector && distance < detector->maxActivationDistance)
				{
					if (raiseClickedEvent)
						detector->click(part, distance);
					return true;
				}
				instance = instance->getParent();
			} while (instance && !dynamic_cast<Workspace*>(instance));
		}
		return false;
	}
}

// Template members emitted by this unit (bodies byte-identical to the 2008-06 client).
template class RBX::Reflection::TSignalDesc<void __cdecl(void)>;

// Name registrations emitted by this unit (bytes and sX relocation identity proven against the 2008-06 client).
template void RBX::Name::callDoDeclare<RBX::sClickDetector>();
