// native-flags: /O2 /Ob2 /Oy /GF /GS- /EHsc /MD /D_AFXDLL /DNDEBUG /D_MBCS /I{headers}/std-noinline-string
// >>> native-status (generated) -- do not edit >>>
// ClipboardActions | 2008-06 | draft (no current byte proof)
// 0/3 mapped addresses byte-exact | 3 unproved | no mapped strings | by auto (+2) (deepseek:deepseek-chat)
// <<< native-status | src 223b17cf | roc native-status --write
#include <afxwin.h>
#include <sstream>
#include <algorithm>
#include <boost/bind.hpp>
#include <intrin.h>
#include "ClipboardVerbs.h"
#include "v8datamodel/DataModel.h"
#include "v8datamodel/Selection.h"
#include "v8datamodel/Workspace.h"
#include "v8xml/SerializerV2.h"
#include "v8xml/XmlSerializer.h"

using namespace RBX;
void __cdecl collectSelection(XmlElement*, boost::shared_ptr<Instance>);
namespace RBX {
inline const Name& Verb::getName() const { return name; }
void recordCameraHistory(const char*, const Instance*);
}

void CopyVerb::doIt(IDataState*)
{
    XmlElement* root = SerializerV2::newRootElement();
    Selection* selected = dataModel ? dataModel->create<Selection>() : NULL;
    std::for_each(selected->selection->begin(), selected->selection->end(), boost::bind(&collectSelection, root, _1));
    std::ostringstream stream(std::ios::out);
    TextXmlWriter writer(stream);
    writer.serialize(root);
    delete root;
    if (OpenClipboard(AfxGetMainWnd()->m_hWnd)) {
        EmptyClipboard();
        std::string text = stream.str();
        HGLOBAL memory = GlobalAlloc(GMEM_MOVEABLE, text.length() + 1);
        char* destination = static_cast<char*>(GlobalLock(memory));
        strcpy(destination, text.c_str());
        GlobalUnlock(memory);
        SetClipboardData(getClipboardFormat(), memory);
        CloseClipboard();
    }
}

void PasteVerb::doIt(IDataState* state)
{
    if (dataModel->findFirstChildByName("NetworkClient")) return;
    if (!OpenClipboard(AfxGetMainWnd()->m_hWnd)) return;
    HGLOBAL data = GetClipboardData(getClipboardFormat());
    const char* text = static_cast<const char*>(GlobalLock(data));
    std::vector<boost::shared_ptr<Instance> > instances;
    {
        std::istringstream input(text, std::ios::in);
        TextXmlParser parser(input.rdbuf());
        std::auto_ptr<XmlElement> root(parser.parse());
        Selection* selected = dataModel ? dataModel->create<Selection>() : NULL;
        Instance* parent = pasteInto && selected->size() == 1 ? selected->front().get() : dataModel->getWorkspace();
        InsertMode mode = pasteInto ? INSERT_TO_TREE : INSERT_TO_3D_VIEW;
        SerializerV2 serializer;
        serializer.loadInstances(root.get(), instances);
        dataModel->getWorkspace()->insertInstances(instances, parent, mode, SUPPRESS_PROMPTS);
        selected->setSelection(instances.begin(), instances.end());
    }
    GlobalUnlock(data);
    CloseClipboard();
    const Name& verbName = getName();
    _ReadWriteBarrier();
    recordCameraHistory(verbName.c_str(), dataModel);
    state->setDirty(true);
}

// Template members emitted by this unit (bodies byte-identical to the 2008-06 client).
template class boost::_bi::value<XmlElement *>;
template class std::_Container_base_aux_alloc_real<std::allocator<XmlElement *> >;
template class std::_Container_base_aux_alloc_real<std::allocator<std::pair<RBX::InstanceHandle const ,int> > >;
template class std::_Container_base_aux_alloc_real<std::allocator<std::pair<std::basic_string<char,std::char_traits<char>,std::allocator<char> > const ,std::basic_string<char,std::char_traits<char>,std::allocator<char> > > > >;
template class std::_Deque_map<XmlElement *,std::allocator<XmlElement *> >;
template class std::_Deque_val<XmlElement *,std::allocator<XmlElement *> >;
template class std::_Tmap_traits<RBX::InstanceHandle,int,std::less<RBX::InstanceHandle>,std::allocator<std::pair<RBX::InstanceHandle const ,int> >,0>;
template class std::_Tree<std::_Tmap_traits<RBX::InstanceHandle,int,std::less<RBX::InstanceHandle>,std::allocator<std::pair<RBX::InstanceHandle const ,int> >,0> >;
template class std::_Tree<std::_Tmap_traits<std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::less<std::basic_string<char,std::char_traits<char>,std::allocator<char> > >,std::allocator<std::pair<std::basic_string<char,std::char_traits<char>,std::allocator<char> > const ,std::basic_string<char,std::char_traits<char>,std::allocator<char> > > >,0> >;
template class std::allocator<std::_Tree_nod<std::_Tmap_traits<RBX::InstanceHandle,int,std::less<RBX::InstanceHandle>,std::allocator<std::pair<RBX::InstanceHandle const ,int> >,0> >::_Node *>;
template class std::allocator<std::_Tree_nod<std::_Tmap_traits<std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::less<std::basic_string<char,std::char_traits<char>,std::allocator<char> > >,std::allocator<std::pair<std::basic_string<char,std::char_traits<char>,std::allocator<char> > const ,std::basic_string<char,std::char_traits<char>,std::allocator<char> > > >,0> >::_Node *>;
template class std::allocator<std::pair<std::basic_string<char,std::char_traits<char>,std::allocator<char> > const ,std::basic_string<char,std::char_traits<char>,std::allocator<char> > > >;
template class std::map<RBX::InstanceHandle,int,std::less<RBX::InstanceHandle>,std::allocator<std::pair<RBX::InstanceHandle const ,int> > >;
template class std::map<std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::basic_string<char,std::char_traits<char>,std::allocator<char> >,std::less<std::basic_string<char,std::char_traits<char>,std::allocator<char> > >,std::allocator<std::pair<std::basic_string<char,std::char_traits<char>,std::allocator<char> > const ,std::basic_string<char,std::char_traits<char>,std::allocator<char> > > > >;
