#include "reflection/Metadata.h"
namespace RBX { namespace Metadata {
RBX::Reflection::Metadata::Class* Reflection::lookup(const RBX::Reflection::ClassDescriptor& descriptor, bool recursive) const
{
    return classes ? classes->lookup(descriptor, recursive) : NULL;
}
}}
