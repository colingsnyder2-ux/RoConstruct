#pragma once
#include <boost/noncopyable.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/once.hpp>
#include <string>
#include <map>

namespace RBX
{
	class Name : boost::noncopyable
	{
	private:
		// TODO: NamMap is a new class, not a typedef
		typedef std::map<std::string, Name*> NamMap;

	private:
		int dictionaryIndex;
	public:
		const std::string name;

	public:
		int getDictionaryIndex() const { return dictionaryIndex; }

		bool empty() const { return &getNullName() == this; }
		const std::string& toString() const { return name; } // guess
		const char* c_str() const { return &name[0]; } // guess
		int compare(const Name& other) const
		{
			return toString().compare(other.toString());
		}

		bool operator <(const RBX::Name& other) const
		{
			return this != &other && this->name < other.name;
		}
		bool operator >(const RBX::Name& other) const
		{
			return this != &other && this->name > other.name;
		}
		bool operator ==(const char* name) const
		{
			return this->name.compare(name) == 0;
		}
		bool operator ==(const std::string& name) const
		{
			return this->name.compare(name) == 0;
		}
		bool operator ==(const Name& other) const
		{
			return this == &other;
		}
		bool operator !=(const char* name) const;
		bool operator !=(const std::string& name) const;
		bool operator !=(const Name& other) const
		{
			return this != &other;
		}

	private:
		Name(const char* sName, int dictionaryIndex)
			: name(sName),
			  dictionaryIndex(dictionaryIndex)
		{}
	public:
		~Name() {}

	private:
		static boost::mutex& mutex();
		static std::map<int, Name*>& dictionary();
		static NamMap& namMap();

	public:
		static const Name& getNullName();
		static const Name& declare(const char* sName, int dictionaryIndex);
		static const Name& lookup(int dictionaryIndex);
		static const Name& lookup(const char* sName);
		static const Name& lookup(const std::string& sName);
		static int compare(Name&, Name&);
	private:
		// NOTE: these have not been checked
		// TODO: these also need to support const char* inputs
		template<const char* sName>
		static const Name& doDeclare()
		{
			static const Name& n = declare(sName, -1);
			return n;
		}

		template<const char* sName>
		static void callDoDeclare()
		{
			doDeclare<sName>();
		}
 public:
 template<const char* sName> static const Name& declare() {
  static boost::once_flag flag=BOOST_ONCE_INIT;
  boost::call_once(&callDoDeclare<sName>,flag);
  return doDeclare<sName>();
 }

	};

	class INamed
	{
	public:
		virtual const Name& getName() const = 0;
	};

	template<typename DerivedClass, const char* ClassName>
	class Named : public DerivedClass
	{
	public:
		typedef Named<DerivedClass, ClassName> Base;

		Named()
			: DerivedClass()
		{
		}

		template<typename Arg0Type>
		Named(Arg0Type arg0)
			: DerivedClass(arg0)
		{
		}

		template<typename Arg0Type, typename Arg1Type>
		Named(Arg0Type arg0, Arg1Type arg1)
			: DerivedClass(arg0, arg1)
		{
		}

		template<typename Arg0Type, typename Arg1Type, typename Arg2Type>
		Named(Arg0Type arg0, Arg1Type arg1, Arg2Type arg2)
			: DerivedClass(arg0, arg1, arg2)
		{
		}

		virtual const Name& getName() const;

	public:
		static const Name& name();
	};
}
