#include "StandardVerbs.h"

namespace RBX {
StandardVerbs::StandardVerbs(DataModel* dm)
    : playDelete(dm), deleteSelection(dm), selectAll(dm), group(dm), ungroup(dm), weld(dm), snap(dm), duplicate(dm),
      attach(dm), track(dm), follow(dm), watch(dm), anchor(dm), translucent(dm), canCollide(dm), canNotSelect(dm),
      allCanSelect(dm), moveUpPlate(dm), moveUpBrick(dm), moveDown(dm), rotate(dm), tilt(dm), primaryController(dm),
      secondaryController(dm), clearStarterpack(dm), clearBackpack(dm), run(dm), stop(dm), reset(dm), firstPerson(dm),
      stats(dm), forceAssertion(dm), engineStats(dm), join(dm), toolArrow(dm), toolResize(dm), toolAxisMove(dm),
      toolFlat(dm), toolGlue(dm), toolWeld(dm), toolStuds(dm), toolInlet(dm), toolHinge(dm), toolRightMotor(dm),
      toolLeftMotor(dm), toolOscillateMotor(dm), toolModelSetFront(dm), toolModelSetPrimaryPart(dm), toolAnchor(dm),
      toolLock(dm), toolFill(dm), toolDropper(dm), toolNull(dm), toolGame(dm), toolGrab(dm), toolClone(dm), toolHammer(dm),
      toolSlingshot(dm), toolRocket(dm), toolLaser(dm) {}
}
