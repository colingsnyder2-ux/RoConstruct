// Rebuild glue: Accoutrement and Tool members rbxgs declares but never defines. The state walk mirrors
// rbxgs Accoutrement::setDesiredState; the frame setters mirror setAttachmentForward/setGripForward.
// Behavioural reconstruction, not byte-verified.
#include "v8datamodel/Accoutrement.h"
#include "v8datamodel/Tool.h"
#include "v8datamodel/JointInstance.h"
#include "v8datamodel/PartInstance.h"
#include "Network/Players.h"

namespace RBX
{
	namespace
	{
		// keep `forward` (column 2) and rebuild the other two axes around a new up or right vector
		G3D::CoordinateFrame withUp(G3D::CoordinateFrame c, const G3D::Vector3& v)
		{
			G3D::Vector3 oldZ = c.rotation.getColumn(2);
			G3D::Vector3 y = v.direction();
			G3D::Vector3 x = y.cross(oldZ);
			x.unitize();
			G3D::Vector3 z = x.cross(y);
			z.unitize();
			c.rotation.setColumn(0, x);
			c.rotation.setColumn(1, y);
			c.rotation.setColumn(2, z);
			return c;
		}

		G3D::CoordinateFrame withRight(G3D::CoordinateFrame c, const G3D::Vector3& v)
		{
			G3D::Vector3 oldY = c.rotation.getColumn(1);
			G3D::Vector3 x = v.direction();
			G3D::Vector3 z = x.cross(oldY);
			z.unitize();
			G3D::Vector3 y = z.cross(x);
			y.unitize();
			c.rotation.setColumn(0, x);
			c.rotation.setColumn(1, y);
			c.rotation.setColumn(2, z);
			return c;
		}

		void dropWeld(boost::shared_ptr<Weld>& weld)
		{
			if (weld)
			{
				weld->setParent(NULL);
				weld.reset();
			}
		}
	}


	// Accoutrement::setAttachmentUp/setAttachmentRight: native (Accoutrement.cpp)

	// undo upTo_Equipped: drop the head weld, listen for pickups again


	// Tool::setGripUp/setGripRight: native (Tool.cpp)

	void Tool::downFrom_Activated() {}

	// Tool::downFrom_Equipped: native (Tool.cpp)

	// walk one state at a time toward the desired state, as Accoutrement::setDesiredState

}
