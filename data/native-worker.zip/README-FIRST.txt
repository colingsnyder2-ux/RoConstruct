RoConstruct Worker
====================

This is the whole helper install. It is deliberately small:

Everything starts from roc.cmd (Linux: ./roc.sh). No arguments opens a menu;
the first run installs what is missing. Models and ChatGPT plan: docs/SETUP.md.

  1. Run install.cmd (Windows) or install.sh (Linux). It checks Python, installs required pip packages
     (pefile, capstone, tzdata), downloads the exact MSVC compiler bundles, registers
     the roconstruct:// link, and opens the website.
  2. Click "Start helping" on the website (or run: roc.cmd launch; Linux: ./roc.sh launch). It asks your
     username, which client, and whether prompts may go to a cloud model.
  3. The worker runs. Cloud models mean your PC stays idle. Only source that
     compiled and matched is uploaded.

Linux needs Wine plus cabextract or 7z. Use ./roc.sh instead of Windows URI links.

Not installed, on purpose: Ollama, Docker, Rev.ng, any local model.
Want a local model later? Install RoConstruct Local AI, or:

    py -3.12 roc.py local-ai

Something wrong? Run:

    py -3.12 roc.py doctor

It prints what is broken and the exact command that fixes it.
