"""Native-source promotion: durable claims, declarative uploads and verified credit."""
import hashlib
import json
import os
import re
import socket
import sqlite3
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent
CLIENT = "2008-06"
MODULE = "rbxgs-app"
LEASE_SECONDS = 2 * 3600
MAX_CLAIMS = 1024
MAX_MERGE = 8  # queued jobs verified together in one linked rebuild
MAX_TARGETS = 100_000
MAX_OVERLAY_PATHS = 1024
MAX_EDITS_PER_PATH = 4096
MAX_OVERLAY_BYTES = 24 * 1024 * 1024
MAX_EVIDENCE_BYTES = 2 * 1024 * 1024
MAX_REQUEST_BYTES = 32 * 1024 * 1024
SCHEMA = """
CREATE TABLE IF NOT EXISTS integration_claims(
 id TEXT PRIMARY KEY, client TEXT, unit TEXT, user TEXT, worker TEXT,
 expires REAL, state TEXT, addresses TEXT, base TEXT, UNIQUE(client,unit));
CREATE TABLE IF NOT EXISTS integration_jobs(
 id TEXT PRIMARY KEY, claim_id TEXT, digest TEXT UNIQUE, user TEXT, model TEXT,
 unit TEXT, base TEXT, patches TEXT, evidence TEXT, state TEXT, phase TEXT,
 created REAL, updated REAL, receipt TEXT);
CREATE TABLE IF NOT EXISTS integration_credit(
 client TEXT, addr TEXT, user TEXT, model TEXT, job TEXT, ts REAL,
 PRIMARY KEY(client,addr));
CREATE TABLE IF NOT EXISTS integration_accepted(
 job TEXT PRIMARY KEY, patches TEXT, ts REAL);
CREATE TABLE IF NOT EXISTS integration_bases(
 revision TEXT PRIMARY KEY, payload TEXT);
CREATE TABLE IF NOT EXISTS integration_config(
 key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS integration_queue_priority(
 job TEXT PRIMARY KEY, requested INTEGER);
CREATE TABLE IF NOT EXISTS integration_type_proposals(
 id TEXT PRIMARY KEY,user TEXT,packet TEXT,state TEXT,job TEXT,created REAL);
"""


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    temp.write_text(json.dumps(value, indent=1) + "\n", encoding="utf-8")
    for attempt in range(8):
        try:
            temp.replace(path)
            break
        except PermissionError as error:
            if getattr(error, "winerror", None) not in (5, 32, 33) or attempt == 7:
                raise
            time.sleep(0.025 * (attempt + 1))


def native_token(root=ROOT, fallback=None, create=False):
    """Read legacy native credentials for older servers; public servers need none."""
    import secrets
    secret = os.environ.get("ROC_NATIVE_TOKEN") or fallback
    path = Path(root) / "local/config/native-integration-token"
    if secret:
        return secret
    if path.exists():
        return path.read_text(encoding="utf-8").strip()
    if create:
        path.parent.mkdir(parents=True, exist_ok=True)
        secret = secrets.token_urlsafe(32)
        with path.open("x", encoding="utf-8") as stream:
            stream.write(secret + "\n")
        path.chmod(0o600)
        return secret
    return None


def validate_patches(patches, allowed_types=()):
    if not isinstance(patches, dict) or not 1 <= len(patches) <= MAX_OVERLAY_PATHS:
        raise ValueError("Need 1-%d source overlay paths" % MAX_OVERLAY_PATHS)
    if len(json.dumps(patches).encode()) > MAX_OVERLAY_BYTES:
        raise ValueError("Overlay exceeds %d bytes" % MAX_OVERLAY_BYTES)
    for name, change in patches.items():
        if not isinstance(name, str):
            raise ValueError("Overlay paths must be strings")
        path = PurePosixPath(name)
        if ("\\" in name or ":" in name or path.is_absolute() or ".." in path.parts
                or path.as_posix() != name or len(path.parts) < 2
                or path.parts[0] not in ("App", "Network", "RbxView", "RbxGraphics", "Rendering")
                or path.suffix not in (".h", ".hpp", ".cpp", ".inl", ".c")):
            raise ValueError("Not a permitted native source path: " + name)
        before = []
        if isinstance(change, dict):
            if set(change) != {"before", "after"} or not isinstance(change["before"], list):
                raise ValueError("A recipe replacement needs before/after lists")
            before, edits = change["before"], change["after"]
        else:
            edits = change
        if not isinstance(edits, list) or not 1 <= len(edits) <= MAX_EDITS_PER_PATH or len(before) > MAX_EDITS_PER_PATH:
            raise ValueError("Need 1-%d edits per path" % MAX_EDITS_PER_PATH)
        for edit in edits:
            if (not isinstance(edit, list) or len(edit) != 2
                    or not all(isinstance(s, str) for s in edit)):
                raise ValueError("An edit must be [old_text,new_text]")
            old, new = edit
            if edit in before:
                continue
            if old.startswith("@") and not old.startswith("@all:"):
                raise ValueError("Uploaded whole-file adoption/directives are not allowed")
            if old == new or not new and not old:
                raise ValueError("Empty or unchanged edit")
            if re.search(r"\b(?:__asm|__emit)\b|\basm\s*\(", new):
                raise ValueError("Assembly/byte emission is not a source promotion")
            if re.search(r"\breinterpret_cast\b|\b(?:char|BYTE)\s+pad\w*\s*\[", new):
                raise ValueError("Padding structs and offset views are not native source")
            types = r"\b(?:struct|class|union)\s+(?:__declspec\([^)]*\)\s+)?([\w:]+)\s*(?::[^;{]+)?\{"
            if set(re.findall(types, new)) - set(re.findall(types, old)) - set(allowed_types):
                raise ValueError("Promote existing native classes; do not append invented snippet types")
    canonical_patches(patches)
    return patches


def canonical_patches(patches, base=None):
    """Windows source identity, preserving the accepted registry's spelling."""
    names = {}
    for name in base or {}:
        key = name.casefold()
        if key in names:
            raise ValueError("Case-colliding native paths: %s / %s" % (names[key], name))
        names[key] = name
    result, seen = {}, {}
    for name, edits in patches.items():
        key = name.casefold()
        if key in seen:
            raise ValueError("Case-colliding native paths: %s / %s" % (seen[key], name))
        seen[key] = name
        result[names.get(key, name)] = edits
    return result


def merge_patches(base, additions):
    base = canonical_patches(base)
    additions = canonical_patches(additions, base)
    result = {name: list(edits) for name, edits in base.items()}
    for name, change in additions.items():
        if isinstance(change, dict):
            if result.get(name, []) != change["before"]:
                raise ValueError("Stale recipe replacement: " + name)
            result[name] = list(change["after"])
        else:
            result.setdefault(name, []).extend(change)
    return result



def project_patches(base, project, accepted):
    """Reproduce a pinned project source baseline, then strictly replay newer accepted batches."""
    if project:
        base = merge_patches(base, project['patches'])
        if digest(base) != project['overlay_digest']:
            raise ValueError('Rebuild source snapshot differs from its pinned overlay')
    included = set(project.get('included_accepted_batches', []))
    for batch in accepted:
        if digest(batch) not in included:
            base = merge_patches(base, batch)
    return base


def overlay_delta(base, candidate):
    """Add recipes, or replace an existing recipe with an exact baseline guard."""
    base = canonical_patches(base)
    candidate = canonical_patches(candidate, base)
    result = {}
    for name in set(base) | set(candidate):
        before, after = base.get(name, []), candidate.get(name, [])
        if not after and before:
            raise ValueError("Cannot remove a complete accepted source overlay: " + name)
        if after[:len(before)] != before:
            result[name] = {"before": before, "after": after}
        elif len(after) > len(before):
            result[name] = after[len(before):]
    return validate_patches(result)


def require_reference_gate(base):
    if base.get('features', {}).get('native_reference_gate') != 1:
        raise ValueError('Server needs native reference verification update and restart before new submissions')


def submission_key(body):
    return digest([body["user"], sorted(body.get("claims", [body.get("claim")])),
                   body["base_revision"], body["model"], body["patches"], body["evidence"], body.get("retry_of")])


def submit_intent(api, directory, folder, body=None, generator=None, base_generator=None, context=None):
    """Persist before sending; recover the exact request, never invent a replacement batch."""
    from roc import worker
    from urllib.parse import urlencode
    ready_file = folder / "ready.json"
    if body is not None and not ready_file.exists():
        atomic_json(folder / "submission.json", body)
        (folder / "submitted-generator.py").write_bytes(generator.read_bytes())
        (folder / "generator-base.py").write_bytes(base_generator.read_bytes())
        atomic_json(folder / "context.json", context or {})
        atomic_json(ready_file, {"request": submission_key(body), "files": {
            name: hashlib.sha256((folder / name).read_bytes()).hexdigest() for name in
            ("submission.json", "submitted-generator.py", "generator-base.py", "context.json")}})
    if not ready_file.exists():
        raise ValueError("Saved request snapshot incomplete; retained for repair: " + str(folder))
    ready = json.loads(ready_file.read_text())
    if any(hashlib.sha256((folder / name).read_bytes()).hexdigest() != value for name, value in ready["files"].items()):
        raise ValueError("Saved request changed; retained for repair: " + str(folder))
    body = json.loads((folder / "submission.json").read_text())
    key = submission_key(body)
    if key != ready["request"]:
        raise ValueError("Saved request identity changed; retained for repair: " + str(folder))
    path = "/v1/integration?" + urlencode(dict(request=key, user=body["user"], claims=1))
    def inspect():
        state = api.call(path)
        jobs = state.get("jobs", []) if state.get("request") == key else []
        return state, next((j for j in jobs if j["user"] == body["user"]), None)
    state, result = inspect()
    if result is None:
        if "claims" in state:
            claims = {c["id"]: c for c in state["claims"]}
            if any(i not in claims or claims[i]["user"] != body["user"] or claims[i]["state"] != "claimed"
                   or claims[i]["expires"] <= time.time() or claims[i]["base_revision"] != body["base_revision"]
                   for i in body["claims"]):
                raise ValueError("Saved submission retained; claims expired, parked or changed. Renew/revalidate before resuming")
        try:
            result = api.call("/v1/integration/submit", body)
        except worker.ApiFailure as error:
            if error.category not in ("offline", "server_fail"):
                raise
            _, result = inspect()
            if result is None:
                raise error
    target = directory / "jobs" / result["id"]
    atomic_json(target / "submission.json", body)
    for name in ("submitted-generator.py", "generator-base.py", "context.json"):
        (target / name).write_bytes((folder / name).read_bytes())
    for identifier in body["claims"]:
        atomic_json(directory / "claims" / identifier / "job.json", result)
    atomic_json(folder / "result.json", result)
    return result


def resume_pending(api, directory, user):
    recovered = []
    for path in sorted((directory / "requests").glob("*/submission.json")):
        if path.with_name("result.json").exists() or json.loads(path.read_text())["user"] != user:
            continue
        result = submit_intent(api, directory, path.parent)
        recovered.append(dict(result, **json.loads(path.with_name("context.json").read_text())))
    return recovered


def adopted_path(tree, name, workspace=None):
    """Native source adoptions belong to this workspace, not a reused vendor checkout."""
    value = name.replace('\\', '/')
    if value.startswith('../../../rebuild/'):
        return (Path(workspace or ROOT) / value[9:]).resolve()
    return Path(os.path.abspath(Path(tree) / name))


def overlay_text(tree, name, patches, workspace=None):
    path = tree/name
    text = path.read_text(errors='replace') if path.exists() else ''
    for old, new in patches.get(name, []):
        if old == '@replace':
            text = adopted_path(tree,new,workspace).read_text(errors='replace')
        elif old.startswith('@all:'):
            text = text.replace(old[5:], new)
        elif old:
            if old not in text:
                raise ValueError('Accepted overlay anchor changed: '+name)
            text = text.replace(old, new, 1)
        else:
            text += new
    return text


def source_root(root):
    """Optional maintainer-owned canonical source lane; contributor uploads cannot select it."""
    root = Path(root)
    directory = root / 'work/integration'
    pin = directory / 'source-root.json'
    if not pin.exists():
        return root
    selected = (directory / json.loads(pin.read_text(encoding='utf-8'))['path']).resolve()
    if selected == (directory/'sources').resolve() or not selected.is_relative_to((directory/'sources').resolve()):
        raise ValueError('Canonical source lane must stay inside work/integration/sources')
    if not (selected / 'rebuild/2008-06/patches/make_rbxgs_client.py').is_file():
        raise ValueError('Canonical source lane is missing trusted rebuild inputs')
    return selected


class Promotions:
    def __init__(self, store, root=ROOT):
        self.store, self.root = store, Path(root)
        self.directory = self.root / "work" / "integration"
        self.source_root = source_root(self.root)
        if self.source_root != self.root:
            import shutil
            shutil.copytree(self.root/'roc', self.source_root/'roc', dirs_exist_ok=True,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            shutil.copy2(self.root/'roc.py', self.source_root/'roc.py')
        self.overlay = self.source_root / "rebuild" / CLIENT / "patches" / "rbxgs-client.json"
        self.generator = self.overlay.with_name("make_rbxgs_client.py")
        self.wake = threading.Event()
        self.worker_error = None
        self.catalog_key, self.catalog_rows = None, []
        self.catalog_done = set()
        self.catalog_lock = threading.Lock()
        self.native_paths = {}
        with store.lock:
            store.db.executescript(SCHEMA)
            initial = self.overlay.with_name("native-promotions.json")
            store.db.execute("INSERT OR IGNORE INTO integration_config VALUES('initial_patches',?)",
                             (initial.read_text(encoding="utf-8") if initial.exists() else "{}",))
            store.db.commit()

    def accepted(self):
        with self.store.lock:
            rows = self.store.db.execute("SELECT patches FROM integration_accepted ORDER BY ts,job").fetchall()
            initial = json.loads(self.store.db.execute(
                "SELECT value FROM integration_config WHERE key='initial_patches'").fetchone()[0])
        result = initial if isinstance(initial, list) else [initial] if initial else []
        for row in rows:
            result.append(json.loads(row[0]))
        return result

    def baseline(self):
        if not self.generator.exists() or not self.overlay.exists():
            raise ValueError("Native rebuild inputs are not installed on this server")
        with self.store.lock, self.store.db:
            base = json.loads(self.overlay.read_text(encoding="utf-8"))
            generator = hashlib.sha256(self.generator.read_bytes()).hexdigest()
            initial = json.loads(self.store.db.execute(
                "SELECT value FROM integration_config WHERE key='initial_patches'").fetchone()[0])
            accepted = initial if isinstance(initial, list) else [initial] if initial else []
            for row in self.store.db.execute("SELECT patches FROM integration_accepted ORDER BY ts,job"):
                accepted.append(json.loads(row[0]))
            result = {"revision": digest([base, generator]), "overlay": base,
                      "generator": generator, "accepted": accepted,
                      "features": {"context": 1, "metrics": 1, "native_reference_gate": 1, "native_recovery_collaboration": 1, "exact_unit_batches": True, "selection_modes": ["easy", "balanced", "large"]},
                      "limits": {"claims": MAX_CLAIMS, "targets": MAX_TARGETS,
                                 "overlay_paths": MAX_OVERLAY_PATHS, "edits_per_path": MAX_EDITS_PER_PATH,
                                 "overlay_bytes": MAX_OVERLAY_BYTES, "evidence_bytes": MAX_EVIDENCE_BYTES,
                                 "request_bytes": MAX_REQUEST_BYTES}}
            self.store.db.execute("INSERT OR IGNORE INTO integration_bases VALUES(?,?)",
                                  (result["revision"], json.dumps(result)))
        return result

    def catalog(self, requested_unit=None, revisit_parked=False):
        with self.catalog_lock:
            return self._catalog(requested_unit, revisit_parked)

    def _catalog(self, requested_unit, revisit_parked):
        path = self.root / "rebuild" / CLIENT / "manifests" / "functions.json"
        report = self.source_root / "rebuild" / CLIENT / "out" / "RbxgsApp" / "report.json"
        queue = path.parent.parent / "out" / "agent-queue.json"
        with self.store.lock:
            accepted_version = self.store.db.execute("SELECT COUNT(*),MAX(ts) FROM integration_accepted").fetchone()
        from roc.native_adapt import type_paths, eligible, symbol_unit
        analysis_path = self.root/'work'/CLIENT/'functions.jsonl'
        analysis_stamp = (analysis_path.stat().st_mtime_ns, analysis_path.stat().st_size) if analysis_path.exists() else None
        names_path = self.root/'rebuild'/CLIENT/'out/native-names.json'
        names_stamp = (names_path.stat().st_mtime_ns,names_path.stat().st_size) if names_path.exists() else None
        coverage_reports = sorted((self.source_root/'rebuild'/CLIENT/'out').glob('*/report.json'))
        coverage_stamp = tuple((str(p),p.stat().st_mtime_ns,p.stat().st_size) for p in coverage_reports)
        indexed_paths, declaration_hash = type_paths(self.source_root, json.loads(self.overlay.read_text()))
        key = (path.stat().st_mtime_ns, self.overlay.stat().st_mtime_ns, report.stat().st_mtime_ns if report.exists() else 0,
               queue.stat().st_mtime_ns if queue.exists() else 0, accepted_version, declaration_hash, analysis_stamp, names_stamp, coverage_stamp)
        if self.catalog_key != key:
            from collections import defaultdict
            tree = self.source_root / "tools/rbxgs/Client"
            accepted_overlay = json.loads(self.overlay.read_text())
            self.native_paths = indexed_paths
            classes = {name.rsplit('::', 1)[-1] for name in indexed_paths}
            source_names = {p.relative_to(tree).as_posix() for p in (tree/'App').rglob('*.cpp')}
            source_names.update(name for name in accepted_overlay if name.startswith('App/') and name.endswith('.cpp'))
            for name in sorted(source_names):
                p = tree/name
                if p.name.startswith("roc_"):
                    continue
                for cls in set(re.findall(r"\b(\w+)::~?\w+\s*\(", overlay_text(tree, name, accepted_overlay, workspace=self.source_root))):
                    self.native_paths.setdefault(cls, set()).add(p.relative_to(tree).as_posix())
            owned = set()
            for coverage in coverage_reports:
                data = json.loads(coverage.read_text())
                if data.get("linked"):
                    owned.update(data.get("owned_addrs", []))
            with self.store.lock:
                accepted = self.store.db.execute("SELECT receipt FROM integration_jobs WHERE state='accepted'").fetchall()
            for receipt, in accepted:
                owned.update(json.loads(receipt).get("gains", []))
            groups = defaultdict(list)
            state = json.loads(queue.read_text()) if queue.exists() else {}
            self.catalog_done = set(state.get('done', []))
            self.catalog_parked = set(state.get("parked", {}))
            from roc import match
            facts = match._functions_at(analysis_path, *analysis_stamp) if analysis_stamp else {}
            for f in json.loads(path.read_text(encoding="utf-8")):
                f = dict(f)
                evidence = facts.get(f['addr'], {})
                if evidence:
                    f.update(dependency_targets=evidence.get('call_targets', []),
                             unresolved_dependencies=sum(a not in owned for a in evidence.get('call_targets', [])),
                             virtual_calls=len(evidence.get('virtual_slots', [])), branches=evidence.get('branches', 0))
                unit = f.get("unit") or ""
                m = re.fullmatch(r"(?:RBX|G3D|Ogre)::(?:\w+::)*(\w+)", unit)
                if (f.get("score") == 100
                        and f["addr"] not in owned and m
                        and (f["size"] >= 24 or 6 <= f["size"] < 24 and symbol_unit(self.native_names().get(f["addr"], {}).get("symbol")) == unit)
                        and m[1] in classes and eligible(unit, f["addr"], self.native_names(), self.native_paths)):
                    groups[unit].append(f)
            self.catalog_rows = sorted(groups.items(), key=lambda x: (-len(x[1]), x[0]))
            self.catalog_key = key
        return [(unit, rows) for unit, rows in self.catalog_rows
                if (unit not in self.catalog_done or unit == requested_unit)
                and (revisit_parked or unit not in self.catalog_parked)]

    def native_names(self):
        """rebuild/2008-06/out/native-names.json ({addr: {symbol, score, strings}}), reloaded when it changes."""
        path = self.root / "rebuild" / CLIENT / "out" / "native-names.json"
        stamp = path.stat().st_mtime if path.exists() else None
        if getattr(self, "_names_stamp", False) != stamp:
            self._names = json.loads(path.read_text()) if stamp else {}
            self._names_stamp = stamp
        return self._names

    def evidence(self):
        """Native discovery inputs for contributor PCs without local rebuild artifacts: rebuilt symbol names, the
        addresses the accepted linked rebuild owns, and every exact mined RBX target ({addr: [unit, size]})."""
        progress = self.directory / "progress-native.json"
        with self.store.lock:
            rows = self.store.db.execute("SELECT addr,unit,size FROM funcs WHERE client=? AND score=100",
                                         (CLIENT,)).fetchall()
        from roc.native_adapt import eligible
        self.catalog()
        targets = {addr: [unit, size] for addr, unit, size in rows
                   if eligible(unit, addr, self.native_names(), self.native_paths)}
        return {"names": self.native_names(),
                "linked": json.loads(progress.read_text())["addresses"] if progress.exists() else [],
                "targets": targets}

    def protected_native(self):
        report = self.root/'rebuild'/CLIENT/'out/RbxgsApp/report.json'
        if not report.exists():
            return None
        owned = set(json.loads(report.read_text()).get('owned_addrs', []))
        with self.store.lock:
            rows = self.store.db.execute("SELECT receipt FROM integration_jobs WHERE state='accepted'").fetchall()
        for receipt, in rows:
            owned.update(json.loads(receipt or '{}').get('gains', []))
        return sorted(owned)

    def packet(self, claim, baselines=None, abi=None, compact=False, protected=None):
        identifier, unit, user, worker, expires, addresses, revision = claim
        evidence = []
        for addr in json.loads(addresses)[:5]:
            path = self.root / "src" / CLIENT / (addr + ".cpp")
            text = path.read_text(errors='replace') if path.exists() else None
            evidence.append({"addr": addr, "source": text[:10000] if text else "Use roc pull to obtain this exact source.",
                             "source_truncated": bool(text and len(text) > 10000),
                             "context_command": 'roc integrate context --claim ' + identifier + ' --address ' + addr})
            if (self.root / "clients/2008-06/Roblox.exe").exists():
                from roc import match
                code, _, _ = match.target(CLIENT, addr)
                instructions = match.disasm(code, int(addr, 16))
                evidence[-1]["disassembly"] = instructions[:200]
                evidence[-1]["disassembly_truncated"] = len(instructions) > 200
        baselines = baselines if baselines is not None else {}
        if revision not in baselines:
            with self.store.lock:
                baselines[revision] = json.loads(self.store.db.execute("SELECT payload FROM integration_bases WHERE revision=?",
                                                                      (revision,)).fetchone()[0])
        if abi is None:
            path = self.root / "rebuild" / CLIENT / "manifests" / "abi-evidence.json"
            abi = json.loads(path.read_text()) if path.exists() else {}
        names = self.native_names()
        packet = {"id": identifier, "client": CLIENT, "module": MODULE, "unit": unit,
                "user": user, "worker": worker, "expires": expires,
                "addresses": json.loads(addresses), "base_revision": revision,
                "snippets": evidence,
                # Real rebuilt symbol per target where vtables/call graph name it, with its current rebuilt score.
                "native_names": {a: names[a] for a in json.loads(addresses) if a in names},
                "native_paths": sorted(self.native_paths.get(unit, self.native_paths.get(unit.rsplit("::", 1)[-1], []))),
                "abi": abi.get(unit, {}),
                "instructions": "Edit make_rbxgs_client.py only; regenerate; submit a declarative overlay. "
                "Derive every change from target bytes. No pad structs, offset views or invented fields."}
        if not compact:
            packet["baseline"] = baselines[revision]
            packet["protected_native"] = protected if protected is not None else self.protected_native()
        return packet

    def claim(self, user, worker, count=1, unit=None, targets=None, compact=False, mode='balanced', units=None,
              revisit_parked=False):
        if mode not in ('easy', 'balanced', 'large'):
            raise ValueError('Invalid native selection mode')
        if type(count) is not int or not 1 <= count <= MAX_CLAIMS:
            raise ValueError("Claim count must be 1-%d" % MAX_CLAIMS)
        if units is not None:
            if (unit is not None or targets is not None or not isinstance(units,list) or not 1 <= len(units) <= MAX_CLAIMS
                    or any(not isinstance(u,str) or not re.fullmatch(r'(?:RBX|G3D|Ogre)::(?:\w+::)*\w+',u) for u in units)
                    or len(set(units)) != len(units)):
                raise ValueError('Exact unit batches require distinct eligible class names')
            count = len(units)
        if targets is not None and (type(targets) is not int or not 1 <= targets <= MAX_TARGETS):
            raise ValueError("Target count must be 1-%d" % MAX_TARGETS)
        if targets is not None:
            count = MAX_CLAIMS
        if not re.fullmatch(r"[A-Za-z0-9_.-]{2,32}", user) or not worker or len(worker) > 100:
            raise ValueError("Need a valid user and worker identity")
        revision = self.baseline()["revision"]
        if revisit_parked:
            candidates = self.catalog(unit, True) if unit else self.catalog(revisit_parked=True)
        else:
            candidates = self.catalog(unit) if unit else self.catalog()
        from roc.integration_context import rank
        abi_path = self.root / 'rebuild' / CLIENT / 'manifests/abi-evidence.json'
        abi = json.loads(abi_path.read_text()) if abi_path.exists() else {}
        names = self.native_names()
        from roc.integration_policy import learned
        with self.store.lock:
            history_rows = self.store.db.execute("SELECT unit,state,receipt FROM integration_jobs WHERE state IN ('accepted','rejected') ORDER BY updated DESC LIMIT 10000").fetchall()
        history = learned([dict(unit=u, state=s, receipt=json.loads(r or '{}')) for u,s,r in history_rows])
        candidates = sorted(candidates, key=lambda item: (
            rank(item[1], names, self.native_paths.get(item[0].rsplit('::', 1)[-1], []), abi.get(item[0]), mode, history.get(item[0])), item[0]))
        now, claimed, target_count = time.time(), [], 0
        with self.store.lock, self.store.db:
            # IMMEDIATE also serializes two separate server connections/processes.
            self.store.db.execute("BEGIN IMMEDIATE")
            for name, functions in candidates:
                if unit and name != unit or units is not None and name not in units:
                    continue
                old = self.store.db.execute("SELECT id,user,worker,expires,state FROM integration_claims "
                                            "WHERE client=? AND unit=?", (CLIENT, name)).fetchone()
                if old and (old[4] == "submitted" or old[3] > now):
                    if old[1:3] != (user, worker) or old[4] != "claimed":
                        continue
                    row = self.store.db.execute("SELECT id,unit,user,worker,expires,addresses,base "
                                                "FROM integration_claims WHERE id=?", (old[0],)).fetchone()
                else:
                    row = (uuid.uuid4().hex, name, user, worker, now + LEASE_SECONDS,
                           json.dumps([f["addr"] for f in functions]), revision)
                    self.store.db.execute("DELETE FROM integration_claims WHERE client=? AND unit=?", (CLIENT, name))
                    self.store.db.execute("INSERT INTO integration_claims "
                                          "(id,client,unit,user,worker,expires,state,addresses,base) "
                                          "VALUES(?,?,?,?,?,?,'claimed',?,?)",
                                          (row[0], CLIENT, name, user, worker, row[4], row[5], revision))
                if targets is not None and row[6] != revision:
                    continue  # A target-sized batch must share one submit baseline.
                claimed.append(row)
                target_count += len(json.loads(row[5]))
                if len(claimed) == count or targets is not None and target_count >= targets:
                    break
        baselines = {}
        abi_path = self.root / "rebuild" / CLIENT / "manifests" / "abi-evidence.json"
        abi = json.loads(abi_path.read_text()) if abi_path.exists() else {}
        protected = self.protected_native()
        result = {"claims": [self.packet(row, baselines, abi, compact, protected) for row in claimed],
                  "classes": len(claimed), "targets": target_count, "mode": mode}
        if compact:
            result["baselines"] = baselines
            result["protected_native"] = protected
        return result

    def renew(self, user, identifier, release=False, reason=None):
        return self.renew_many(user, [identifier], release, reason)

    def renew_many(self, user, identifiers, release=False, reason=None, action=None):
        if (not isinstance(identifiers, list) or not 1 <= len(identifiers) <= MAX_CLAIMS
                or any(not isinstance(i, str) for i in identifiers) or len(set(identifiers)) != len(identifiers)):
            raise ValueError("Need 1-%d distinct claim IDs" % MAX_CLAIMS)
        action = action or ("release" if release else "renew")
        if action not in ("renew", "release", "park", "unpark"):
            raise ValueError("Unknown claim operation")
        if action == "release" and reason:
            raise ValueError("Release frees a claim immediately; use park --reason TEXT for a two-hour blocker")
        if action == "park" and (not isinstance(reason, str) or not reason.strip()):
            raise ValueError("Park requires a blocker reason; use release for diagnostic cleanup")
        if reason is not None and (not isinstance(reason, str) or len(reason) > 500):
            raise ValueError("Park reason must be at most 500 characters")
        with self.store.lock, self.store.db:
            now = time.time()
            expires = now if action in ("release", "unpark") else now + LEASE_SECONDS
            state = "parked: " + reason if action == "park" else "released" if action in ("release", "unpark") else "claimed"
            condition = "state LIKE 'parked:%'" if action == "unpark" else "state='claimed' AND expires>?"
            changed = self.store.db.executemany("UPDATE integration_claims SET expires=?,state=? "
                "WHERE id=? AND user=? AND " + condition,
                [(expires, state, identifier, user) + (() if action == "unpark" else (now,)) for identifier in identifiers]).rowcount
        return {"ok": changed == len(identifiers), "changed": changed, "requested": len(identifiers),
                "operation": action, "state": state, "expires": expires}

    def submit(self, user, body):
        patches = validate_patches(body.get("patches"))
        model, evidence = body.get("model"), body.get("evidence")
        if not isinstance(model, str) or not model.strip() or len(model) > 120:
            raise ValueError("Record the actual model, or human for manual work")
        if not isinstance(evidence, str) or not 1 <= len(evidence.encode()) <= MAX_EVIDENCE_BYTES:
            raise ValueError("Evidence notes are required")
        cited = set(re.findall(r"(?i)(?<![0-9a-f])[0-9a-f]{8}(?![0-9a-f])", evidence.lower()))
        identifiers = body.get("claims", [body.get("claim")])
        if (not isinstance(identifiers, list) or not 1 <= len(identifiers) <= MAX_CLAIMS
                or any(not isinstance(i, str) for i in identifiers) or len(set(identifiers)) != len(identifiers)):
            raise ValueError("Need 1-%d distinct claim IDs" % MAX_CLAIMS)
        identifiers = sorted(identifiers)
        base = str(body.get("base_revision", ""))
        retry = body.get("retry_of")
        if retry is not None and (not isinstance(retry, str) or not re.fullmatch(r"[0-9a-f]{32}", retry)):
            raise ValueError("Invalid retry job ID")
        key = submission_key(dict(user=user, claims=identifiers, base_revision=base, model=model,
                                  patches=patches, evidence=evidence, retry_of=retry))
        with self.store.lock, self.store.db:
            self.store.db.execute("BEGIN IMMEDIATE")
            previous = self.store.db.execute("SELECT id,state FROM integration_jobs WHERE digest=?", (key,)).fetchone()
            if previous:
                return {"id": previous[0], "state": previous[1], "duplicate": True}
            if retry and not self.store.db.execute("SELECT 1 FROM integration_jobs WHERE id=? AND user=? "
                    "AND state='rejected' AND claim_id=?", (retry, user, json.dumps(identifiers))).fetchone():
                raise ValueError("Only your rejected batch can be retried")
            claims = []
            for identifier in identifiers:
                claim = self.store.db.execute("SELECT unit,addresses,base FROM integration_claims "
                    "WHERE id=? AND user=? AND state='claimed' AND expires>?", (identifier, user, time.time())).fetchone()
                if not claim or claim[2] != base:
                    raise ValueError("Missing, expired or mismatched claim; renew/reclaim before submitting")
                if not cited.intersection(json.loads(claim[1])):
                    raise ValueError("Cite a claimed target address for " + claim[0])
                claims.append(claim)
            job = uuid.uuid4().hex
            self.store.db.execute("INSERT INTO integration_jobs VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (job, json.dumps(identifiers), key, user, model, ", ".join(c[0] for c in claims), base, json.dumps(patches), evidence,
                 "queued", "queued", time.time(), time.time(), None))
            for identifier in identifiers:
                self.store.db.execute("UPDATE integration_claims SET state='submitted' WHERE id=?", (identifier,))
        self.wake.set()
        return {"id": job, "state": "queued", "duplicate": False}

    def status(self, identifier=None, request=None, user=None, include_claims=False):
        with self.store.lock:
            where, params = ("WHERE id=? ", (identifier,)) if identifier else ("", ())
            if request:
                where, params = "WHERE digest=? AND user=? ", (request, user)
            rows = self.store.db.execute("SELECT id,user,model,unit,state,phase,created,updated,receipt "
                "FROM integration_jobs " + where + "ORDER BY created DESC LIMIT 100", params).fetchall()
            leaders = self.store.db.execute("SELECT user,model,COUNT(*) FROM integration_credit "
                                           "GROUP BY user,model ORDER BY COUNT(*) DESC,user").fetchall()
            parked = self.store.db.execute("SELECT unit,state,expires,id,user FROM integration_claims "
                                           "WHERE state LIKE 'parked:%' AND expires>?", (time.time(),)).fetchall()
            claims = self.store.db.execute("SELECT id,unit,user,worker,expires,state,base FROM integration_claims").fetchall() if include_claims else []
        result = {"verifier_error": self.worker_error,
                "parked": [{"unit": u, "reason": s[8:], "until": e, "id": i, "user": owner} for u, s, e, i, owner in parked],
                "jobs": [dict(zip(("id", "user", "model", "unit", "state", "phase", "created", "updated", "receipt"),
                                 (*r[:-1], json.loads(r[-1]) if r[-1] else None))) for r in rows],
                "leaderboard": [{"user": u, "model": m, "native_credits": n} for u, m, n in leaders]}
        if request:
            result["request"] = request
        if include_claims:
            queue = self.root / "rebuild" / CLIENT / "out/agent-queue.json"
            queue_parked = json.loads(queue.read_text()).get("parked", {}) if queue.exists() else {}
            result.update(inventory={unit: [f["addr"] for f in functions] for unit, functions in self.catalog()},
                          parked_units=sorted({row[0] for row in parked} | set(queue_parked)),
                          claims=[dict(zip(("id", "unit", "user", "worker", "expires", "state", "base_revision"), row)) for row in claims])
        return result

    def force_queue(self, user, identifier):
        """Prioritize an owned queued batch; the active verifier keeps running."""
        if not isinstance(identifier, str) or not re.fullmatch(r"[0-9a-f]{32}", identifier):
            raise ValueError("Invalid batch ID")
        with self.store.lock, self.store.db:
            self.store.db.execute("BEGIN IMMEDIATE")
            row = self.store.db.execute("SELECT user,state FROM integration_jobs WHERE id=?", (identifier,)).fetchone()
            if not row or row[0] != user:
                raise ValueError("Batch not found or belongs to another user")
            if row[1] != "queued":
                raise ValueError("Force queue requires a queued batch; current state: " + row[1])
            self.store.db.execute("INSERT OR REPLACE INTO integration_queue_priority VALUES(?,?)",
                                  (identifier, time.time_ns()))
            self.store.db.execute("UPDATE integration_jobs SET phase=CASE WHEN phase='solo' THEN phase "
                                  "ELSE 'priority queued' END,updated=? WHERE id=?", (time.time(), identifier))
        self.wake.set()
        return {"id": identifier, "state": "queued", "priority": "next", "waits_for_active": True}

    def take(self):
        """Prioritized jobs first, then FIFO. Later jobs from the same user/model/baseline that edit disjoint files ride along
        in one verification (one linked rebuild for all); a merged batch that fails is re-queued as solo jobs."""
        fields = ("id", "user", "model", "unit", "base", "patches", "evidence", "phase")
        with self.store.lock, self.store.db:
            self.store.db.execute("BEGIN IMMEDIATE")
            rows = [dict(zip(fields, r)) for r in self.store.db.execute(
                "SELECT j.id,j.user,j.model,j.unit,j.base,j.patches,j.evidence,j.phase FROM integration_jobs j "
                "LEFT JOIN integration_queue_priority p ON p.job=j.id "
                "WHERE j.state='queued' ORDER BY p.requested IS NULL,p.requested DESC,j.created")]
            if not rows:
                return None
            lead, members = rows[0], [rows[0]]
            if lead["phase"] != "solo" and not lead['evidence'].startswith('TYPE-PROMOTION:'):
                files = {name.casefold() for name in json.loads(lead["patches"])}
                for row in rows[1:]:
                    patches = {name.casefold() for name in json.loads(row["patches"])}
                    if len(members) < MAX_MERGE and row["phase"] != "solo" and not row['evidence'].startswith('TYPE-PROMOTION:') and not files & patches and \
                            (row["user"], row["model"], row["base"]) == (lead["user"], lead["model"], lead["base"]):
                        members.append(row)
                        files |= patches
            for row in members:
                self.store.db.execute("DELETE FROM integration_queue_priority WHERE job=?", (row["id"],))
                self.store.db.execute("UPDATE integration_jobs SET state='verifying',phase=?,updated=? WHERE id=?",
                                      ("snapshot" if row is lead else "merged into " + lead["id"][:8], time.time(), row["id"]))
        job = {k: lead[k] for k in fields[:-1]}
        if len(members) > 1:
            merged = {}
            for row in members:
                merged.update(json.loads(row["patches"]))
            job.update(patches=json.dumps(merged), members=[row["id"] for row in members],
                       unit=", ".join(row["unit"] for row in members),
                       evidence="\n\n".join(row["evidence"] for row in members))
        return job

    def progress(self, identifier, phase):
        with self.store.lock, self.store.db:
            self.store.db.execute("UPDATE integration_jobs SET phase=?,updated=? WHERE id=? AND state='verifying'",
                                  (phase, time.time(), identifier))

    def finish(self, job, receipt, publish=None):
        """Called only by the server's verifier; no client result/credit endpoint."""
        with self.store.lock, self.store.db:
            self.store.db.execute("BEGIN IMMEDIATE")
            current = self.store.db.execute("SELECT state FROM integration_jobs WHERE id=?", (job["id"],)).fetchone()
            if not current or current[0] != "verifying":
                return False
            accepted = receipt.get("accepted") is True
            members = job.get("members", [job["id"]])
            if accepted:
                own_claims = {claim for member in members for claim in json.loads(self.store.db.execute(
                    'SELECT claim_id FROM integration_jobs WHERE id=?', (member,)).fetchone()[0])}
                gains = set(receipt.get('gains', receipt['new_distinct']))
                gained_units = set()
                if self.store.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='funcs'").fetchone():
                    for addr in gains:
                        row = self.store.db.execute('SELECT unit FROM funcs WHERE client=? AND addr=?', (CLIENT,addr)).fetchone()
                        if row and row[0]:
                            gained_units.add(row[0])
                conflicts = [unit for identifier,unit,addresses in self.store.db.execute(
                    "SELECT id,unit,addresses FROM integration_claims WHERE client=? AND (state='submitted' OR (state='claimed' AND expires>?))",
                    (CLIENT,time.time())) if identifier not in own_claims and
                    (unit in gained_units or gains.intersection(json.loads(addresses)))]
                if conflicts:
                    accepted = False
                    receipt.update(accepted=False, lease_conflicts=sorted(conflicts),
                                   reason='Candidate gains belong to other active class claims: '+', '.join(sorted(conflicts)))
            if len(members) > 1 and not accepted:
                # One member may have broken the shared build: verify each on its own instead of rejecting all.
                note = json.dumps({"merged_failure": receipt.get("reason", ""), "merged_jobs": members})
                for identifier in members:
                    self.store.db.execute("UPDATE integration_jobs SET state='queued',phase='solo',receipt=?,updated=? "
                                          "WHERE id=? AND state='verifying'", (note, time.time(), identifier))
                return False
            if accepted:
                for addr in receipt["new_distinct"]:
                    self.store.db.execute("INSERT OR IGNORE INTO integration_credit VALUES(?,?,?,?,?,?)",
                                         (CLIENT, addr, job["user"], job["model"], job["id"], time.time()))
                self.store.db.execute("INSERT INTO integration_accepted VALUES(?,?,?)",
                                      (job["id"], job["patches"], time.time()))
                if publish:
                    initial = json.loads(self.store.db.execute(
                        "SELECT value FROM integration_config WHERE key='initial_patches'").fetchone()[0])
                    accepted_patches = initial if isinstance(initial, list) else [initial] if initial else []
                    for row in self.store.db.execute("SELECT patches FROM integration_accepted ORDER BY ts,job"):
                        accepted_patches.append(json.loads(row[0]))
                    publish(accepted_patches)
                receipt["credits"] = self.store.db.execute("SELECT COUNT(*) FROM integration_credit WHERE job=?",
                                                           (job["id"],)).fetchone()[0]
            receipt.update({"job": job["id"], "user": job["user"], "model": job["model"], "unit": job["unit"]})
            if len(members) > 1:
                receipt["merged_jobs"] = members
            for member in members:
                self.store.db.execute("UPDATE integration_jobs SET state=?,phase=?,receipt=?,updated=? WHERE id=?",
                    ("accepted" if accepted else "rejected", "complete", json.dumps(receipt), time.time(), member))
                self.store.db.execute('UPDATE integration_type_proposals SET state=? WHERE job=?',
                    ('accepted' if accepted else 'rejected', member))
                claims = self.store.db.execute("SELECT claim_id FROM integration_jobs WHERE id=?", (member,)).fetchone()[0]
                for identifier in json.loads(claims):
                    self.store.db.execute("UPDATE integration_claims SET state=?,expires=? WHERE id=?",
                        ("released" if accepted else "claimed", 0 if accepted else time.time() + LEASE_SECONDS, identifier))
        self.catalog_key = None
        return True


def add_standins(claim):
    """Each exact snippet's binary-proven placeholder -> real symbol map (roc/standins.py), when it compiles here."""
    from roc import standins
    for item in claim.get("snippets", []):
        try:
            item["standins"] = standins.mapping(CLIENT, item["addr"], item["source"])
        except Exception as error:  # noqa: BLE001 - evidence is optional; the packet stays usable without it
            item["standins_error"] = str(error)[:200]
    return claim


def run_generator(generator, root, timeout=120):
    """Regenerate overlays with visible liveness and a bounded startup wait."""
    started = time.monotonic()
    print("Generating native overlay...", flush=True)
    process = subprocess.Popen([sys.executable, "-u", str(generator)], cwd=root,
                               stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    while True:
        try:
            output, _ = process.communicate(timeout=max(.01, min(10, timeout - (time.monotonic() - started))))
            break
        except subprocess.TimeoutExpired:
            elapsed = time.monotonic() - started
            print("Native overlay generator still running (%ds)" % elapsed, flush=True)
            if elapsed >= timeout:
                process.kill()
                process.communicate()
                raise TimeoutError("Native overlay generator exceeded %ds; stopped private generator" % timeout)
    if process.returncode:
        raise RuntimeError("Native overlay generation failed: " + output.decode(errors="replace")[-1500:])
    print("Native overlay ready (%.1fs)" % (time.monotonic() - started), flush=True)


def sync_client_baseline(root, base, only_if_clean=False):
    generator = root / "rebuild/2008-06/patches/make_rbxgs_client.py"
    overlay = generator.with_name("rbxgs-client.json")
    marker = root / "work/integration-client/baseline.json"
    if only_if_clean:
        if not marker.exists():
            return False
        previous = json.loads(marker.read_text())
        current = hashlib.sha256(generator.read_bytes()).hexdigest()
        if current != previous["generator"] or current != base["generator"] or \
                json.loads(overlay.read_text()) != previous["overlay"]:
            return False
    atomic_json(generator.with_name("native-promotions.json"), base["accepted"])
    if (hashlib.sha256(generator.read_bytes()).hexdigest() == base["generator"] and overlay.exists()
            and json.loads(overlay.read_text()) == base["overlay"]):
        atomic_json(marker, base)
        print("Accepted native overlay unchanged; regeneration skipped", flush=True)
        return True
    run_generator(generator, root)
    if json.loads(overlay.read_text()) != base["overlay"]:
        raise ValueError("Local source/overlay baseline differs from server; update before claiming")
    atomic_json(marker, base)
    return True


def command(args):
    from roc import worker
    if args.action == 'adapt':
        from roc.native_adapt import command as adapt
        return adapt(args)
    if args.action == 'check':
        from roc.integration_local import command as local_check
        return local_check(args)
    if args.action == "fingerprint":
        from roc.integration_verify import input_hashes
        started = time.monotonic()
        full, live = input_hashes(ROOT)
        print(json.dumps({"inputs": full, "live": live, "seconds": round(time.monotonic() - started, 3)}))
        return
    settings = worker.load_settings()
    server = args.server or settings.get("server") or worker.site_server()
    user = args.user or settings.get("user")
    if not server or not user:
        raise SystemExit("Run roc config --server URL --user NAME first")
    api = worker.Api(server, args.token or settings.get("native_token") or native_token() or settings.get("token"))
    directory = ROOT / "work" / "integration-client"
    generator = ROOT / "rebuild/2008-06/patches/make_rbxgs_client.py"
    overlay = generator.with_name("rbxgs-client.json")
    action = args.action

    if action == 'header-report':
        if not args.class_name or args.exact is None or args.total is None or not args.model:
            raise SystemExit('header-report needs --class-name, --exact, --total and --model')
        try:
            result = api.call('/v1/integration/header-report', {'user': user,
                'class': args.class_name, 'exact': args.exact, 'total': args.total, 'note': args.note or '', 'model': args.model})
            print(json.dumps(result))
            return result
        finally:
            api.close()

    if action == 'context':
        if not args.claim or not getattr(args, 'address', None):
            raise SystemExit('context needs --claim ID --address ADDR')
        from roc.integration_context import retrieve
        try:
            return retrieve(api, directory, args.claim, args.address)
        finally:
            api.close()

    if action == 'audit':
        from roc.integration_audit import audit
        try:
            result = audit(ROOT, api.call('/v1/integration/base'), getattr(args, 'baseline_artifacts', None),
                           current_profile=getattr(args, 'current_profile', False))
            print(json.dumps(dict(passed=result['passed'], mode=result['mode'],
                                  legacy_inventory_reproduced=result['legacy_inventory_reproduced'],
                                  accepted_references=result.get('accepted_references'), seconds=result['seconds'], distinct=result['distinct'],
                                  preserved_native=len(result['unchanged_owned']), artifacts=result['snapshot']), indent=1))
            return result
        except (OSError, ValueError, RuntimeError) as error:
            raise SystemExit(str(error)) from None
        finally:
            api.close()

    if action == 'metrics':
        try:
            result = api.call('/v1/integration/metrics?hours=' + str(args.hours))
            integration_path = directory/'metrics.json'
            atomic_json(integration_path, result)
            print(json.dumps(dict({k:v for k,v in result.items() if k != 'learned_tasks'},
                                  learned_task_count=len(result.get('learned_tasks', {})), details=str(integration_path)), indent=1))
            return result
        finally:
            api.close()

    if action == "invite":
        print("Native integration is public. No invitation or native token required.")
        return

    if action == "resume":
        try:
            recovered = resume_pending(api, directory, user)
            print(json.dumps(recovered, indent=1) if recovered else "No unresolved saved submissions")
            return recovered
        finally:
            api.close()

    if action == "submit":
        require_reference_gate(api.call("/v1/integration/base"))
        recovered = resume_pending(api, directory, user)
        if recovered:
            print("Recovered saved submission(s); no new batch created: " + json.dumps(recovered))
            api.close()
            return recovered

    if action in ("renew", "release", "park", "unpark") and (getattr(args, "claim", None) or action == "unpark"):
        if action == "release" and args.reason:
            raise SystemExit("release frees immediately; omit --reason for cleanup, or use park --reason TEXT")
        if action == "park" and not args.reason:
            raise SystemExit("park requires --reason TEXT; release does not park")
        try:
            if args.claim:
                identifiers = [args.claim]
            elif args.all or args.unit:
                status = api.call("/v1/integration?claims=1")
                identifiers = [c["id"] for c in status["parked"] if c.get("user") == user and
                               (not args.unit or c["unit"] == args.unit)]
            else:
                raise SystemExit("unpark needs --claim ID, --unit CLASS, or --all; only owned parks can change")
            if not identifiers:
                return print("No owned parked claims selected")
            result = api.call("/v1/integration/" + action, {"user": user, "claims": identifiers, "reason": args.reason})
            print(action + ": " + json.dumps(result))
            return result
        except worker.ApiFailure as error:
            if action in ("park", "unpark") and "Unknown integration action" in str(error):
                raise SystemExit("Server needs native protocol 3 for park/unpark; claims unchanged") from None
            raise
        finally:
            api.close()

    if action == "force-queue":
        if not args.id:
            raise SystemExit("Force queue needs --id JOB_ID")
        try:
            result = api.call("/v1/integration/force-queue", {"user": user, "id": args.id})
        except worker.ApiFailure as error:
            if error.category == "bad_request" and "Unknown integration action" in str(error):
                raise SystemExit("Server needs the force-queue update and restart; active verification is unchanged") from None
            raise
        finally:
            api.close()
        print("Priority queued %s; starts after active verification completes" % result["id"])
        return

    if action == "next":
        base = api.call("/v1/integration/base")
        if getattr(args, "mode", "balanced") != "balanced" and not base.get("features", {}).get("selection_modes"):
            raise SystemExit("Server needs the selection-mode update and restart before this request")
        limits = base.get("limits", {"claims": 16})
        if args.count > limits["claims"] or getattr(args, "targets", None) is not None and not limits.get("targets"):
            raise SystemExit("Server needs the bulk integration update and restart before this request")
        if not generator.exists() or not (ROOT / "tools/rbxgs/Client/App/include").exists():
            raise SystemExit("Native integration needs the rebuild recipes and your local rbxgs source tree; see docs/INTEGRATION.md")
        if hashlib.sha256(generator.read_bytes()).hexdigest() != base["generator"]:
            raise SystemExit("Generator differs from server; preserve local edits, sync/update before claiming")
        atomic_json(generator.with_name("native-promotions.json"), base["accepted"])
        run_generator(generator, ROOT)
        if json.loads(overlay.read_text()) != base["overlay"]:
            raise SystemExit("Local overlay does not match the server baseline")
        identity_file = directory / "identity.json"
        if not identity_file.exists():
            atomic_json(identity_file, {"id": uuid.uuid4().hex})
        identity = json.loads(identity_file.read_text())["id"]
        bulk = args.count > 16 or getattr(args, "targets", None) is not None
        result = api.call("/v1/integration/claim", {"user": user,
            "worker": user + "@" + socket.gethostname()[:40] + ":" + identity[:12],
            "count": args.count, "unit": args.unit, "targets": getattr(args, "targets", None),
            "compact": bulk, "mode": getattr(args, 'mode', 'balanced'),
            "revisit_parked": getattr(args, 'revisit_parked', False)}, **({"timeout": 300} if bulk else {}))
        previous_jobs = {j["id"]: j for j in api.call("/v1/integration").get("jobs", [])}
        stale = []
        for claim in result["claims"]:
            marker = directory / "claims" / claim["id"] / "job.json"
            if not marker.exists():
                continue
            job = previous_jobs.get(json.loads(marker.read_text(encoding="utf-8"))["id"], {})
            reason = (job.get("receipt") or {}).get("reason", "")
            if job.get("state") == "rejected" and "Stale recipe replacement" in reason:
                stale.append(claim["id"])
        if stale:
            api.call("/v1/integration/park", {"user": user, "claims": stale,
                "reason": "Previously rejected stale recipe replacement."})
            result["claims"] = [c for c in result["claims"] if c["id"] not in stale]
            print("Skipped %d previously stale claim(s); parked for fresh evidence." % len(stale))
        for claim in result["claims"]:
            if "baseline" not in claim:
                claim["baseline"] = result["baselines"][claim["base_revision"]]
            if "protected_native" not in claim:
                claim["protected_native"] = result.get("protected_native")
            folder = directory / "claims" / claim["id"]
            if not (folder / "packet.json").exists():
                if not bulk:
                    add_standins(claim)
                atomic_json(folder / "packet.json", claim)
                if generator.exists():
                    (folder / "generator-base.py").write_bytes(generator.read_bytes())
                prompt = ("Integrate " + claim["unit"] + " in RoConstruct (2008-06).\n\n"
                    "Read CLAUDE.md, rebuild/2008-06/POLICY.md and patches/make_rbxgs_client.py.\n"
                    "Read packet.json: exact snippets are evidence, not structures to paste.\n"
                    "Each snippet's standins maps its placeholder externs to the real symbol/RTTI type/import the exe\n"
                    "relocates at that spot (binary-proven); use the real names, never the placeholders.\n"
                    "Find the real class/method; derive fields, signatures, constants and control flow from bytes.\n"
                    "Change real C++ only through make_rbxgs_client.py overlay patches. Cite addresses.\n"
                    "Never edit tools/, src/, clients/ or bounds.json. No padding structs or offset views.\n"
                    "If a whole-file redesign is needed, record the blocker and release the claim.\n"
                    "Record address-specific evidence in notes.md. Then submit with:\n"
                    "  roc integrate submit --claim " + claim["id"] + " --model ACTUAL_MODEL --evidence-file notes.md\n"
                    "The server independently rebuilds, checks M2/M4a/M5, size/base, ownership and distinct counts.\n"
                    "Only verified new distinct native bodies receive separate native credit; raw mining points stay unchanged.\n")
                prompt += ('Retrieve full source, assembly and native declarations per function:\n'
                           '  roc integrate context --claim ' + claim['id'] + ' --address ADDR\n'
                           'Fast feedback (private workspace, no native credit):\n'
                           '  roc integrate check --claim ' + claim['id'] + ' --fast\n'
                           '  roc integrate check --claim ' + claim['id'] + ' --bytes\n')
                (folder / "PROMPT.md").write_text(prompt, encoding="utf-8")
                (folder / "notes.md").write_text("Evidence addresses: " + " ".join(claim["addresses"][:5]) +
                                                "\n\nDescribe the byte-proven source correction here.\n", encoding="utf-8")
            if len(result["claims"]) <= 16:
                print("%s: %d targets; claim %s\n  %s" % (claim["unit"], len(claim["addresses"]), claim["id"], folder))
        if result["claims"]:
            batch = directory / "batches" / (uuid.uuid4().hex + ".json")
            total = sum(len(c["addresses"]) for c in result["claims"])
            atomic_json(batch, {"claims": [c["id"] for c in result["claims"]], "targets": total})
            print("Claimed %d classes / %d targets; batch %s" % (len(result["claims"]), total, batch))
            if getattr(args, "targets", None) and total < args.targets:
                print("Requested %d targets; fewer eligible unclaimed targets available." % args.targets)
        if not result["claims"]:
            suffix = " (including parked classes)." if getattr(args, 'revisit_parked', False) else "; try --revisit-parked to retry parked classes."
            print("No unclaimed eligible native classes available" + suffix)
        return

    if action in ("submit", "renew", "release", "park", "unpark"):
        if action == "release" and args.reason:
            raise SystemExit("release frees immediately; omit --reason for cleanup, or use park --reason TEXT")
        if action == "park" and not args.reason:
            raise SystemExit("park requires --reason TEXT; release does not park")
        paths = sorted((directory / "claims").glob("*/packet.json"))
        claims = [json.loads(p.read_text(encoding="utf-8")) for p in paths]
        states = {j["id"]: j["state"] for j in api.call("/v1/integration")["jobs"]}
        def active(c):
            marker = directory / "claims" / c["id"] / "job.json"
            return not marker.exists() or states.get(json.loads(marker.read_text())["id"]) == "rejected"
        claims = [c for c in claims if c["user"] == user and
                  (c["id"] == args.claim if args.claim else active(c))]
        batch_file = getattr(args, "batch", None)
        if batch_file:
            if args.claim:
                raise SystemExit("Select --claim or --batch, not both")
            selected = set(json.loads(Path(batch_file).read_text(encoding="utf-8"))["claims"])
            claims = [c for c in claims if c["id"] in selected]
            if {c["id"] for c in claims} != selected:
                raise SystemExit("Batch contains missing or inactive local claims")
        if not claims or (len(claims) > 1 and not args.all and not batch_file):
            raise SystemExit("Select --claim ID, --batch FILE, or --all for local claims")
        if action != "submit":
            if len(claims) > 1 and api.call("/v1/integration/base").get("limits"):
                print(api.call("/v1/integration/" + action,
                    {"user": user, "claims": [c["id"] for c in claims], "reason": args.reason}))
            else:
                for c in claims:
                    print(c["id"], api.call("/v1/integration/" + action,
                        {"user": user, "claim": c["id"], "reason": args.reason}))
            return
        if not args.model or not args.evidence_file:
            raise SystemExit("Submit needs --model ACTUAL_MODEL (or human) and --evidence-file FILE")
        if len({c["base_revision"] for c in claims}) != 1:
            raise SystemExit("Batch claims have different bases; submit each baseline separately")
        fresh_base = api.call("/v1/integration/base")
        if fresh_base["revision"] != claims[0]["base_revision"]:
            sync_client_baseline(ROOT, fresh_base)
            raise SystemExit("Skipped stale claim: server baseline advanced and was synced; claim a fresh target")
        run_generator(generator, ROOT)
        patches = overlay_delta(claims[0]["baseline"]["overlay"], json.loads(overlay.read_text(encoding="utf-8")))
        if hasattr(args, 'no_local_check') and not args.no_local_check:
            from roc.integration_local import command as local_check
            import copy
            check_args = copy.copy(args)
            if not any(getattr(check_args, key, None) for key in ('claim', 'batch', 'all')):
                check_args.claim = claims[0]['id']
            report = local_check(check_args, fail=False)
            unresolved = (report.get('compile_ok') and not report.get('lost') and report.get('targets')
                          and all(t['status'] != 'mismatch' for t in report['targets'].values()))
            if not report.get('ok') and not unresolved:
                raise SystemExit('Local preflight failed; repair diagnostics before submitting')
        body = {"user": user, "claims": [c["id"] for c in claims], "model": args.model,
                "base_revision": claims[0]["base_revision"], "patches": patches,
                "evidence": Path(args.evidence_file).read_text(encoding="utf-8")}
        if args.retry:
            if any(not (directory / "claims" / c["id"] / "job.json").exists() for c in claims):
                raise SystemExit("--retry needs an existing rejected batch")
            jobs = {json.loads((directory / "claims" / c["id"] / "job.json").read_text())["id"] for c in claims}
            if len(jobs) != 1:
                raise SystemExit("Retry one rejected batch at a time")
            body["retry_of"] = jobs.pop()
        folder = directory / "requests" / submission_key(body)
        result = submit_intent(api, directory, folder, body, generator,
            directory / "claims" / claims[0]["id"] / "generator-base.py",
            {"applied_paths": getattr(args, "applied_paths", []),
             "preflight_artifacts": getattr(args, "preflight_artifacts", None)})
        print("Queued %s (%d classes, one independent verification)" % (result["id"], len(claims)))
        if not args.wait:
            return
        args.id, action = result["id"], "watch"

    if action in ("status", "watch"):
        previous = None
        while True:
            result = api.call("/v1/integration" + ("?id=" + args.id if args.id else ""))
            phases = [(j["id"], j["state"], j["phase"]) for j in result["jobs"]]
            if phases != previous:
                for job in result["jobs"]:
                    print("%s %s | %s | %s" % (job["id"], job["state"], job["phase"], job["unit"]))
                    if job["receipt"]:
                        print(json.dumps(job["receipt"], indent=1))
                previous = phases
            if action == "status" or not result["jobs"] or all(j["state"] in ("accepted", "rejected") for j in result["jobs"]):
                print("Native credits:", json.dumps(result["leaderboard"]))
                api.close()
                if action == "watch":
                    if not result["jobs"] and args.id:
                        raise SystemExit("Native job missing: " + args.id)
                    if any(j["state"] == "rejected" for j in result["jobs"]):
                        raise SystemExit(1)
                return
            time.sleep(2)

    if action == "sync":
        base = api.call("/v1/integration/base")
        current = hashlib.sha256(generator.read_bytes()).hexdigest()
        if current != base["generator"]:
            statuses = {j["id"]: j for j in api.call("/v1/integration")["jobs"]}
            restored = False
            for path in (directory / "jobs").glob("*/submitted-generator.py"):
                if path.parent.name not in statuses or statuses[path.parent.name]["state"] != "accepted":
                    continue
                old = path.with_name("generator-base.py")
                if (hashlib.sha256(path.read_bytes()).hexdigest() == current
                        and hashlib.sha256(old.read_bytes()).hexdigest() == base["generator"]):
                    generator.write_bytes(old.read_bytes())
                    restored = True
                    break
            if not restored:
                raise SystemExit("Generator differs from server; preserve local edits and update before syncing")
        sync_client_baseline(ROOT, base)
        print("Accepted overlays synced:", base["revision"])
