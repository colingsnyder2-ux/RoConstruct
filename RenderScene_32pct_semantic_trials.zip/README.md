# RenderScene 32% targeted trials

Baseline (verified by user): 32% on `force_geometry_access` (the first two forced rendering inlines). No new scores claimed.

## Evidence-backed hypotheses

- **aabb_two_copies**: Target 0x7AC658 first copies `target+0x27C` into a local `Ogre::AxisAlignedBox` even before the coordinate-range test. On the alternative geometry path it takes another copy, constructs a box, calls `merge`, and passes the result **by value** to `sub_7A9C40`. The old C++ incorrectly built a fresh AABB and assigned it. This model preserves separate object lifetimes.
- **aabb_one_copy**: Same but uses a single `existing` copy to isolate the cost of the extra copy on the alternative branch.
- **zero_vector_constructed** and **zero_vector_default**: Target 0x7AB5D7 has a lazy initialized static zero vector guarded by a bit. The old source used a constant-initialized `static float[3]` (which typically emits no runtime guard). This tests whether `Ogre::Vector3` static initialization gets the right guard.
- **typed_matrix4**: Target matrix data at `[esp+0x260]` is an OGRE-sized matrix; use `Ogre::Matrix4` instead of 128 unknown bytes. The earlier buffer-size-only trial had no effect; this tests the *type*.
- **force_submesh_only** and **force_worldpos_only**: Isolate which forced geometry accessor contributed to 31% → 32%.
- **aabb_two_copies_plus_zero** and **aabb_two_copies_plus_matrix**: Explicit interactions, only useful if the standalone trial improves matching.
- **fp_fast**: One MSVC floating-point codegen profile trial (guard this: it overrides default client flags).

## Windows usage

1. Extract the zip **into the RoConstruct repository root**, where `roc.cmd` lives.
2. Run `powershell -NoProfile -ExecutionPolicy Bypass -File .\RenderScene_32pct_test.ps1`.
3. Read score table and `.log` files under `RenderScene_32pct_logs`.
4. Do not overwrite the working `src\2008-06\007ab0a0.cpp` unless a candidate scores **above 32%**.

The score is not evidence of a working Roblox client; compiling a C++ candidate is not a functional/runtime equivalence test.
The above trials may fail to compile against the actual historical Ogre headers. They are scratch checks; keep and report failures instead of silently replacing the source.
