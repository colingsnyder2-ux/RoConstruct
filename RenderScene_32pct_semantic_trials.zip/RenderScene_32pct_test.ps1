$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot
$logDir = Join-Path $PSScriptRoot "RenderScene_32pct_logs"
New-Item -ItemType Directory -Force -Path $logDir | Out-Null
$rows = @()
$files = Get-ChildItem -File "RenderScene_32pct_*.cpp" | Sort-Object Name
foreach ($f in $files) {
    Write-Host "`n--- $($f.Name) ---"
    $result = (& .\roc.cmd check 2008-06 007ab0a0 --file $f.FullName --context 3 2>&1 | Out-String)
    $result | Set-Content (Join-Path $logDir ($f.BaseName + ".log"))
    $score = "FAILED"
    if ($result -match '007ab0a0\s+(\d+)%') { $score = $Matches[1] + "%" }
    Write-Host "$score - $($f.Name)"
    if ($score -eq "FAILED") {
        Write-Host (($result -split "`n" | Select-Object -First 12) -join "`n")
    }
    $rows += [pscustomobject]@{ Candidate=$f.BaseName; Score=$score }
}
$rows | Format-Table -AutoSize
$rows | Export-Csv (Join-Path $logDir "summary.csv") -NoTypeInformation
Write-Host "`nReference best = 32%. Your live src file was not modified."
