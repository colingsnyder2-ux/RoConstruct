$ErrorActionPreference = "Continue"
$files = @(
    "RenderScene_24pct_inline_render.cpp",
    "RenderScene_24pct_inline_all.cpp"
)
$logDir = "RenderScene_inline_results"
New-Item -ItemType Directory -Path $logDir -Force | Out-Null
foreach ($file in $files) {
    Write-Host "`n=== $file ==="
    if (!(Test-Path ".\$file")) {
        Write-Host "Missing $file"
        continue
    }
    $output = & .\roc.cmd check 2008-06 007ab0a0 --file ".\$file" --context 3 2>&1
    $output | Out-File "$logDir\$file.log" -Encoding utf8
    $output | Select-Object -First 55
    Write-Host "Saved full diff: $logDir\$file.log"
}
